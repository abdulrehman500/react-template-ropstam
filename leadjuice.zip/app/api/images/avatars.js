//  const avatars = [
//    '/images/avatars/pp_girl.svg',
//    '/images/avatars/pp_girl.svg',
//    '/images/avatars/pp_girl2.svg',
//    '/images/avatars/pp_girl3.svg',
//    '/images/avatars/pp_girl4.svg',
//    '/images/avatars/pp_girl5.svg',
//    '/images/avatars/pp_boy.svg',
//    '/images/avatars/pp_boy2.svg',
//    '/images/avatars/pp_boy3.svg',
//    '/images/avatars/pp_boy4.svg',
//    '/images/avatars/pp_boy5.svg',
//  ];

const avatars = [
  'https://randomuser.me/api/portraits/women/0.jpg',
  'https://randomuser.me/api/portraits/women/8.jpg',
  'https://randomuser.me/api/portraits/women/17.jpg',
  'https://randomuser.me/api/portraits/women/90.jpg',
  'https://randomuser.me/api/portraits/women/44.jpg',
  'https://randomuser.me/api/portraits/women/18.jpg',
  'https://randomuser.me/api/portraits/men/75.jpg',
  'https://randomuser.me/api/portraits/men/4.jpg',
  'https://randomuser.me/api/portraits/men/40.jpg',
  'https://randomuser.me/api/portraits/men/83.jpg',
  'https://randomuser.me/api/portraits/men/3.jpg',
];

export default avatars;
