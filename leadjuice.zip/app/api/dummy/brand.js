module.exports = {
  name: 'Lead Juice',
  desc: 'Lead Juice',
  prefix: 'leadJuice',
  footerText: 'Lead Juice All Rights Reserved 2019',
  logoText: 'Lead Juice',
};
