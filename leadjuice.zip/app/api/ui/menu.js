module.exports = [
  {
    key: 'home',
    name: 'Home',
    icon: 'home',
    child: [

      {
        key: 'dashboard',
        name: 'Dashboard',
        icon: 'settings_brightness',
        link: '/app'
      }
    ]
  },
  {
    key: 'company',
    name: 'Company',
    icon: 'business',
    child: [

      {
        key: 'add_company',
        name: 'Add Company',
        icon: 'add',
        link: '/app/add-company'
      },
      {
        key: 'view',
        name: 'View Company',
        icon: 'list',
        link: '/app/company'
      }

    ]
  },
  {
    key: 'staff',
    name: 'Staff Members',
    icon: 'supervisor_account',
    child: [
      {
        key: 'add_staff',
        name: 'Add Staff',
        icon: 'settings_brightness',
        link: '/app/add-staff'
      },
      {
        key: 'view_staff',
        name: 'View Staff',
        icon: 'settings_brightness',
        link: '/app/staff'
      },

    ]
  },
  {
    key: 'customers',
    name: 'Contacts',
    icon: 'people_outline',
    child: [
      {
        key: 'add_customer',
        name: 'Add Contacts',
        icon: 'settings_brightness',
        link: '/app/add-customer'
      },
      {
        key: 'view_customer',
        name: 'View Contacts',
        icon: 'settings_brightness',
        link: '/app/customers'
      },
      {
        key: 'add_list',
        name: 'Add List',
        icon: 'settings_brightness',
        link: '/app/add-list'
      },
      {
        key: 'view-list',
        name: 'View List',
        icon: 'settings_brightness',
        link: '/app/list'
      }
    ]
  },
  {
    key: 'funnels',
    name: 'Campaigns',
    icon: 'filter_list',
    link: '/app/camapigns',

    child: [

      {
        key: 'add_camapign',
        name: 'Add Campaign',
        icon: 'settings_brightness',
        link: '/app/add-campaign'
      },
      {
        key: 'manage_campaign',
        name: 'Manage Campaigns',
        icon: 'settings_brightness',
        link: '/app/campaigns'
      },
      {
        key: 'add_template',
        name: 'Add Email Template',
        icon: 'settings_brightness',
        link: '/app/add-template'
      },
      {
        key: 'email_template',
        name: 'Email Templates',
        icon: 'settings_brightness',
        link: '/app/email-templates'
      }
    ]
  },
  {
    key: 'conversations',
    name: 'Conversations',
    icon: 'forum',
    link: '/app/camapigns',

    child: [


      {
        key: 'conversations',
        name: 'Conversation',
        icon: 'settings_brightness',
        link: '/app/conversations'
      }
    ]
  },
  {
    key: 'settings',
    name: 'Settings',
    icon: 'settings',
    child: [

      {
        key: 'settings',
        name: 'Settings',
        icon: 'settings_brightness',
        link: '/app/settings'
      }
    ]
  },
];
