import React, { PureComponent } from 'react';
import PropTypes from 'prop-types';
import { fade } from '@material-ui/core/styles/colorManipulator';
import { createMuiTheme, withStyles } from '@material-ui/core/styles';
import Grid from '@material-ui/core/Grid';
import withWidth, { isWidthDown } from '@material-ui/core/withWidth';
import {
  LineChart,
  Line,
  AreaChart,
  Area, Pie, Cell, PieChart
} from 'recharts';

//import { data1 } from 'enl-api/chart/chartMiniData';
import { data6 } from './sampleData';

import bitcoinLogo from 'enl-images/crypto/bitcoin.png';
import rippleLogo from 'enl-images/crypto/ripple.png';
import moneroLogo from 'enl-images/crypto/monero.png';
import iotaLogo from 'enl-images/crypto/iota.png';
import { injectIntl, intlShape } from 'react-intl';
import styles from './widget-jss';
import CounterWidget from '../Counter/CounterWidget';
import CounterTrading from '../Counter/CounterTrading';
import messages from './messages';
//import { data6 } from '../../containers/Charts/demos/sampleData';
import Box from '@material-ui/core/Box';
import { data1 } from './sampleData';

import red from '@material-ui/core/colors/red';
import pink from '@material-ui/core/colors/pink';
import purple from '@material-ui/core/colors/purple';
import indigo from '@material-ui/core/colors/indigo';
import blue from '@material-ui/core/colors/blue';
import cyan from '@material-ui/core/colors/cyan';
import teal from '@material-ui/core/colors/teal';
import { BarSimple } from '../../containers/Charts/demos';
import ThemePallete from 'enl-api/palette/themePalette';
const colors = [red[500], pink[500], purple[500], indigo[500], blue[500], cyan[500], teal[500]];
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  CartesianAxis,
  Tooltip,
  Legend,
  ResponsiveContainer
} from 'recharts';
import Paper from '@material-ui/core/Paper';
import Avatar from '@material-ui/core/Avatar';
import Typography from '@material-ui/core/Typography';
import CountUp from 'react-countup';
import TrendingUp from '@material-ui/icons/TrendingUp';
import TrendingDown from '@material-ui/icons/TrendingDown';
import TrendingFlat from '@material-ui/icons/TrendingFlat';
import axios from '../../../server/axios-common';
const RADIAN = Math.PI / 180;
const renderCustomizedLabel = ({
  cx,
  cy,
  midAngle,
  innerRadius,
  outerRadius,
  percent,
}) => {
  const radius = innerRadius + ((outerRadius - innerRadius) * 0.5);
  const x = cx + (radius * Math.cos(-midAngle * RADIAN));
  const y = cy + (radius * Math.sin(-midAngle * RADIAN));

  return (
    <text x={x} y={y} fill="white" textAnchor={x > cx ? 'start' : 'end'} dominantBaseline="central">
      {`${(percent * 100).toFixed(0)}%`}
    </text>
  );
};

renderCustomizedLabel.propTypes = {
  cx: PropTypes.number,
  cy: PropTypes.number,
  midAngle: PropTypes.number,
  innerRadius: PropTypes.number,
  outerRadius: PropTypes.number,
  percent: PropTypes.number,
};

renderCustomizedLabel.defaultProps = {
  cx: 0,
  cy: 0,
  midAngle: 0,
  innerRadius: 0,
  outerRadius: 0,
  percent: 0,
};
const theme = createMuiTheme(ThemePallete.magentaTheme);

const color = ({
  primary: theme.palette.primary.main,
  primaryDark: theme.palette.primary.dark,
  secondary: theme.palette.secondary.main,
  secondaryDark: theme.palette.secondary.dark,
});
class CounterCryptoWidget extends PureComponent {
  constructor(props){
    super(props);

    this.state = {
      lead: 0,

      prospect:0,
      consult:0,
      lead_t: 0,

      prospect_t:0,
      consult_t:0,
      close:0,
      company: 0,
      contacts: 0,
      spend:0,
      total:0,
      roi:0,

    };

  }


  componentDidMount() {


    var self = this;

    axios.get('/dashboardPayment',{
      headers: {
    'Authorization': localStorage.auth,
      }
    })
      .then(function (res) {

console.log(res)
if(res.data.meta.status==200)
        {

        var record=res.data.data;
        if(record.close[0])
          self.setState({
            close:record.close[0].price,
          });
        if(record.lead[0])
          self.setState({
            lead:record.lead[0].price,
            lead_t:record.lead[0].count,
          });
        if(record.prospect[0])
          self.setState({
            prospect:record.prospect[0].price,
            prospect_t:record.prospect[0].count,
          });
        if(record.consult[0])
          self.setState({
            consult:record.consult[0].price,
            consult_t:record.consult[0].count,
          });
        if(record.spend[0])
          self.setState({
            spend:record.spend[0].price,
          });

}


      })


  }
  render() {
    const {
      classes,
      width,
      intl,
      theme
    } = this.props;
    const {
      consult,
      consult_t,
      prospect,
      lead,
      prospect_t,
      lead_t,
      spend,
      close,
      barchart
    } = this.state;
    console.log(this.state)
    const getCondition = (pos, val) => {
      if (pos === 'up') {
        return (
          <span className={classes.up}>
            <TrendingUp />
            &nbsp;
            {val}
            %
          </span>
        );
      }
      if (pos === 'down') {
        return (
          <span className={classes.down}>
            <TrendingDown />
            &nbsp;
            {val}
            %
          </span>
        );
      }
      return (
        <span className={classes.flat}>
          <TrendingFlat />
          &nbsp;0%
        </span>
      );
    };

    return (
      <div className={classes.rootCounter}>
        <Grid container spacing={2}>
          <Grid item md={8} xs={12}>
            <Grid container spacing={2}>
              <Grid item sm={4} xs={12}>
                <CounterTrading
                  color={"#FF1616"}
                  unitBefore="$ "
                  start={0}
                  end={lead}
                  lowest={lead/lead_t}
                  duration={3}
                  title="Leads"
                  secondary="Cost Per Lead"
                  logo={bitcoinLogo}


                >


                </CounterTrading>

                <Box display="flex" justifyContent="center" p={1} m={1} style={{background:'#b9b7b81c'}} >


                  <PieChart
                    width={400}
                    height={200}
                    margin={{
                      top: 5,
                      right: 30,
                      left: 20,
                      bottom: 5
                    }}
                  >
                    <Pie
                      dataKey="value"
                      data={data6}
                      cx={200}
                      cy={100}
                      labelLine={false}
                      label={renderCustomizedLabel}
                      outerRadius={80}
                      fill="#FF1616"
                    >
                      {
                        data6.map((entry, index) => <Cell key={index.toString()} fill={colors[index % colors.length]} />)
                      }
                    </Pie>
                  </PieChart>

                </Box>
              </Grid>
              <Grid item sm={4} xs={12}>
                <CounterTrading
                  color={"#FE7E0F"}
                  unitBefore="$ "
                  start={0}
                  end={prospect}
                  lowest={prospect/prospect_t}

                  duration={3}
                  title="Prospect"
                  secondary="Cost Per Prospect"

                  logo={bitcoinLogo}

                >


                </CounterTrading>
                <Box display="flex" flexDirection="row-reverse" p={1} m={1} style={{background:'#b9b7b81c'}} >

                  <PieChart
                    width={400}
                    height={200}
                    margin={{
                      top: 5,
                      right: 30,
                      left: 20,
                      bottom: 5
                    }}
                  >
                    <Pie
                      dataKey="value"
                      data={data6}
                      cx={200}
                      cy={100}
                      labelLine={false}
                      label={renderCustomizedLabel}
                      outerRadius={80}
                      fill="#FE7E0F"
                    >
                      {
                        data6.map((entry, index) => <Cell key={index.toString()} fill={colors[index % colors.length]} />)
                      }
                    </Pie>
                  </PieChart>
                </Box>
              </Grid>
              <Grid item sm={4} xs={12}>


                <CounterTrading
                  color={"#87C830"}
                  unitBefore="$ "
                  start={0}
                  end={consult}
                  lowest={consult/consult_t}

                  duration={3}
                  title="Consult"
                  secondary="Cost Per Consult"

                logo={bitcoinLogo}
                  position="up"
                  value={5.6}

                >


                </CounterTrading>
                <Box display="flex" flexDirection="row-reverse" p={1} m={1} style={{background:'#b9b7b81c'}} >

                  <PieChart
                    width={400}
                    height={200}
                    margin={{
                      top: 5,
                      right: 30,
                      left: 20,
                      bottom: 5
                    }}
                  >
                    <Pie
                      dataKey="value"
                      data={data6}
                      cx={200}
                      cy={100}
                      labelLine={false}
                      label={renderCustomizedLabel}
                      outerRadius={80}
                      fill="#87C830"
                    >
                      {
                        data6.map((entry, index) => <Cell key={index.toString()} fill={colors[index % colors.length]} />)
                      }
                    </Pie>
                  </PieChart>
                </Box>
              </Grid>
                 </Grid>
          </Grid>
          <Grid item md={4} xs={12}>
            <Grid container>
              <Grid container spacing={2}>
                <Grid item md={4} xs={12}>
                  <CounterWidget
                    color="lead-color"
                    unitBefore={'$'}
                    start={0}
                    end={spend}
                    duration={3}
                    title='SPEND'

                  >

                  </CounterWidget>
                </Grid>
                <Grid item md={4} xs={12}>
                  <CounterWidget
                    color="prospect-color"
                    unitBefore={'$'}

                    start={0}
                    end={consult+prospect+lead+close}
                    duration={3}
                    title='RETURN'
                  >

                  </CounterWidget>
                </Grid>
                <Grid item md={4} xs={12}>
                  <CounterWidget
                    color="consult-color"
                    unitAfter={'%'}

                    start={0}
                    end={((consult+prospect+lead+close)/spend)*100}
                    duration={3}
                    title='ROI'
                  >

                  </CounterWidget>
                </Grid>
                 </Grid>

              <Box display="flex" flexDirection="row-reverse" p={1} m={1} style={{background:'#b9b7b81c',width:'100%'}} >

              <BarChart
                width={410}
                //style={{width:300}}
                height={450}
                  data={[
                    {
                      name: 'Earning Chart',
                      SPEND: spend,
                      RETURN: consult+prospect+lead+close
                    },

                  ]}
                  margin={{
                    top: 5,
                    right: 30,
                    left: 20,
                    bottom: 5
                  }}
                >
                  <defs>
                    <linearGradient id="colorUv" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor={color.primary} stopOpacity={0.8} />
                      <stop offset="95%" stopColor={color.primaryDark} stopOpacity={1} />
                    </linearGradient>
                    <linearGradient id="colorPv" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor={color.secondary} stopOpacity={0.8} />
                      <stop offset="95%" stopColor={color.secondaryDark} stopOpacity={1} />
                    </linearGradient>
                  </defs>
                  <XAxis dataKey="name" tickLine={false} />
                  <YAxis axisLine={false} tickSize={3} tickLine={false} tick={{ stroke: 'none' }} />
                  <CartesianGrid vertical={false} strokeDasharray="3 3" />
                  <CartesianAxis vertical={false} />
                  <Tooltip />
                  <Legend />
                  <Bar dataKey="SPEND" fillOpacity="1" fill="url(#colorUv)" />
                  <Bar dataKey="RETURN" fillOpacity="0.8" fill="url(#colorPv)" />
                </BarChart>
              </Box>
            </Grid>
          </Grid>
        </Grid>
      </div>
    );
  }
}

CounterCryptoWidget.propTypes = {
  classes: PropTypes.object.isRequired,
  theme: PropTypes.object.isRequired,
  width: PropTypes.string.isRequired,
  intl: intlShape.isRequired
};

export default withWidth()(withStyles(styles, { withTheme: true })(injectIntl(CounterCryptoWidget)));
