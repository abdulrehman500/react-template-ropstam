import React, { Fragment, useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import { withStyles } from '@material-ui/core/styles';

import Hidden from '@material-ui/core/Hidden';

import PhoneIcon from '@material-ui/icons/Phone';
import Chat from '@material-ui/icons/Chat';
import Mail from '@material-ui/icons/Mail';

import AccountBox from '@material-ui/icons/AccountBox';
import MoreVertIcon from '@material-ui/icons/MoreVert';
import PlaylistAddCheck from '@material-ui/icons/PlaylistAddCheck';
import Menu from '@material-ui/core/Menu';
import MenuItem from '@material-ui/core/MenuItem';
import List from '@material-ui/core/List';
import ListItem from '@material-ui/core/ListItem';
import ListItemText from '@material-ui/core/ListItemText';
import ListItemSecondaryAction from '@material-ui/core/ListItemSecondaryAction';
import ListItemAvatar from '@material-ui/core/ListItemAvatar';
import IconButton from '@material-ui/core/IconButton';
import Avatar from '@material-ui/core/Avatar';
import Tooltip from '@material-ui/core/Tooltip';

import dataContact from 'enl-api/apps/contactData';
import { injectIntl, intlShape, FormattedMessage } from 'react-intl';
import messages from './messages';
import styles from './widget-jss';
import PapperBlock from '../PapperBlock/PapperBlock';
import axios from '../../../server/axios-common';




/* END Tab Container */

/* Contact List */
function ContactList(props) {


  const [dataContact, setdataContact] = useState([]);
  console.log('contact')
  console.log(dataContact);
  useEffect(() => {
    var self = this;

    axios.get('/hotLeads',{
      headers: {
    'Authorization': localStorage.auth,
      }
    })
      .then(function (res) {

        var status=res.data.meta.status;
if(status==200)
{
        var record=res.data.data;
        console.log(res);
        setdataContact(record);
}



      })

  }, []);
  const getItem = dataArray => dataArray.map(data => (
    <ListItem
      button
      key={data._id}
    >

      <ListItemText primary={data.first_name + ' ' +data.last_name} secondary={data.phone} />
      <Hidden xsDown>
        <ListItemSecondaryAction>
          <Tooltip title={props.intl.formatMessage(messages.chat)}>
            <IconButton className={props.classes.blueText} aria-label="Chat">
              <Chat />
            </IconButton>
          </Tooltip>
          <Tooltip title={props.intl.formatMessage(messages.email)}>
            <IconButton className={props.classes.pinkText} aria-label="Email">
              <Mail />
            </IconButton>
          </Tooltip>

        </ListItemSecondaryAction>
      </Hidden>
      <Hidden smUp>
        <ListItemSecondaryAction>
          <IconButton
            aria-label="More"
            aria-haspopup="true"
            onClick={props.openMenu}
          >
            <MoreVertIcon />
          </IconButton>
        </ListItemSecondaryAction>
      </Hidden>
    </ListItem>
  ));
  return (
    <List>
      {getItem(dataContact)}
    </List>
  );
}

ContactList.propTypes = {
  classes: PropTypes.object.isRequired,
  openMenu: PropTypes.func.isRequired,
  intl: intlShape.isRequired
};

const ContactListStyled = withStyles(styles)(injectIntl(ContactList));
/* END Contact List */

/* Conversation List */

class ContactWidget extends React.Component {
  state = {
    value: 0,
    anchorEl: null,
    anchorElAction: null,
  };

  handleChange = (event, value) => {
    this.setState({ value });
  };

  handleOpen = event => {
    this.setState({ anchorEl: event.currentTarget });
  };

  handleOpenAction = event => {
    this.setState({ anchorElAction: event.currentTarget });
  };

  handleClose = () => {
    this.setState({
      anchorEl: null,
      anchorElAction: null
    });
  };

  render() {
    const { classes, intl } = this.props;
    const { value, anchorEl, anchorElAction } = this.state;
    const open = Boolean(anchorEl);
    const openAct = Boolean(anchorElAction);
    return (
      <Fragment>

          <PapperBlock whiteBg noMargin title='Hot Leads' icon="people_outline" desc="">

        <ContactListStyled openMenu={this.handleOpen} />
        </PapperBlock>
      </Fragment>
    );
  }
}

ContactWidget.propTypes = {
  classes: PropTypes.object.isRequired,
  intl: intlShape.isRequired
};

export default withStyles(styles)(injectIntl(ContactWidget));
