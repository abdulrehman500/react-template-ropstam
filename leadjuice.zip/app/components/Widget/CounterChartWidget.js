import React, { PureComponent } from 'react';
import PropTypes from 'prop-types';
import { withStyles } from '@material-ui/core/styles';
import { fade } from '@material-ui/core/styles/colorManipulator';
import Grid from '@material-ui/core/Grid';
import {
  BarChart, Bar,
  AreaChart, Area,
  LineChart, Line,
} from 'recharts';
import { data1 } from 'enl-api/chart/chartMiniData';
import AssignmentReturned from '@material-ui/icons/AssignmentReturned';
import { injectIntl, intlShape } from 'react-intl';
import messages from './messages';
import CounterWidget from '../Counter/CounterWidget';
import styles from './widget-jss';
import axios from '../../../server/axios-common';

class CounterChartWidget extends PureComponent {
  constructor(props){
    super(props);

    this.state = {
      lead: 0,

      prospect:0,
      consult:0,
      close:0,
      company: 0,
      contacts: 0,
    };

  }


  componentDidMount() {


    var self = this;

    axios.get('/dashboard',{
      headers: {
    'Authorization': localStorage.auth,
      }
    })
      .then(function (res) {


        var record=res.data.data;
        self.setState({
          lead:record.lead,
          prospect:record.prospect,
          consult:record.consult,
          close:record.close,
          company:record.company,
          contacts:record.contacts,


        });


      })


  }

  render() {
    const { classes, intl, theme } = this.props;
    const { lead, prospect, consult,close, company, contacts } = this.state;
    return (
      <div className={classes.rootCounter}>
        <Grid container spacing={2}>
          <Grid item md={2} xs={6}>
            <CounterWidget
              color="lead-color"
              start={0}
              end={lead}
              duration={3}
              title='Leads'

            >
              <AreaChart width={100} height={60} data={data1}>
                <Area type="monotone" dataKey="uv" stroke={theme.palette.secondary.main} fill={fade(theme.palette.secondary.main, 0.5)} />
              </AreaChart>
            </CounterWidget>
          </Grid>
          <Grid item md={2} xs={6}>
            <CounterWidget
              color="prospect-color"
              start={0}
              end={prospect}
              duration={3}
              title='Prospect'
            >
              <AreaChart width={100} height={60} data={data1}>
                <Area type="monotone" dataKey="uv" stroke={theme.palette.secondary.main} fill={fade(theme.palette.secondary.main, 0.5)} />
              </AreaChart>
            </CounterWidget>
          </Grid>
          <Grid item md={2} xs={6}>
            <CounterWidget
              color="consult-color"
              start={0}
              end={consult}
              duration={3}
              title='Consult'
            >
              <AreaChart width={100} height={60} data={data1}>
                <Area type="monotone" dataKey="uv" stroke={theme.palette.secondary.main} fill={fade(theme.palette.secondary.main, 0.5)} />
              </AreaChart>
            </CounterWidget>
          </Grid>
          <Grid item md={2} xs={6}>
            <CounterWidget
              color="close-color"
              start={0}
              end={close}
              duration={3}
              title='Close'
            >
              <AreaChart width={100} height={60} data={data1}>
                <Area type="monotone" dataKey="uv" stroke={theme.palette.secondary.main} fill={fade(theme.palette.secondary.main, 0.5)} />
              </AreaChart>
            </CounterWidget>
          </Grid>
          <Grid item md={2} xs={6}>
            <CounterWidget
              color="primary-light"
              start={0}
              end={company}
              duration={3}
              title='Company'
            >
              <AreaChart width={100} height={60} data={data1}>
                <Area type="monotone" dataKey="uv" stroke={theme.palette.secondary.main} fill={fade(theme.palette.secondary.main, 0.5)} />
              </AreaChart>
            </CounterWidget>
          </Grid>
          <Grid item md={2} xs={6}>
            <CounterWidget
              color="primary-light"
              start={0}
              end={contacts}
              duration={3}
              title='Contacts'
            >
              <AreaChart width={100} height={60} data={data1}>
                <Area type="monotone" dataKey="uv" stroke={theme.palette.secondary.main} fill={fade(theme.palette.secondary.main, 0.5)} />
              </AreaChart>
            </CounterWidget>
          </Grid>
        </Grid>
      </div>
    );
  }
}

CounterChartWidget.propTypes = {
  classes: PropTypes.object.isRequired,
  intl: intlShape.isRequired,
  theme: PropTypes.object.isRequired,
};

export default withStyles(styles, { withTheme: true })(injectIntl(CounterChartWidget));
