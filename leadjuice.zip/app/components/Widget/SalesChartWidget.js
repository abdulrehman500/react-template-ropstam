import React, { PureComponent } from 'react';
import PropTypes from 'prop-types';
import { withStyles } from '@material-ui/core/styles';
import Grid from '@material-ui/core/Grid';
import classNames from 'classnames';
import CardGiftcard from '@material-ui/icons/CardGiftcard';
import LocalLibrary from '@material-ui/icons/LocalLibrary';
import Computer from '@material-ui/icons/Computer';
import Toys from '@material-ui/icons/Toys';
import Avatar from '@material-ui/core/Avatar';
import Divider from '@material-ui/core/Divider';
import Style from '@material-ui/icons/Style';
import Typography from '@material-ui/core/Typography';
import purple from '@material-ui/core/colors/purple';
import blue from '@material-ui/core/colors/blue';
import cyan from '@material-ui/core/colors/cyan';
import pink from '@material-ui/core/colors/pink';
import colorfull from 'enl-api/palette/colorfull';

import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  CartesianAxis,
  Tooltip,
  ResponsiveContainer,
  PieChart, Pie, Cell,
  Legend
} from 'recharts';
import { dataSales } from 'enl-api/chart/chartData';
import { data2 } from 'enl-api/chart/chartMiniData';
import { injectIntl, intlShape, FormattedMessage } from 'react-intl';
import messages from './messages';
import styles from './widget-jss';
import PapperBlock from '../PapperBlock/PapperBlock';
import GridListTile from '@material-ui/core/GridListTile';
import axios from '../../../server/axios-common';

const color = ({
  primary: '#C41212',
  secondary: '#FE7E0F',
  third: '#87C830',
  fourth: '#8E3CCB',
});

const colorsPie = [purple[500], blue[500], cyan[500], pink[500]];

class SalesChartWidget extends PureComponent {

  constructor(props){
    super(props);

    this.state = {
      lead: 0,

      prospect:0,
      consult:0,
      close:0,
      company: 0,
      contacts: 0,
    };

  }


  componentDidMount() {


    var self = this;

    axios.get('/dashboard',{
      headers: {
    'Authorization': localStorage.auth,
      }
    })
      .then(function (res) {


        var record=res.data.data;
        self.setState({
          lead:record.lead,
          prospect:record.prospect,
          consult:record.consult,
          close:record.close,
          company:record.company,
          contacts:record.contacts,


        });


      })


  }
  render() {
    const { classes, intl } = this.props;
    const { lead, prospect, consult, close } = this.state;
    return (
      <PapperBlock whiteBg noMargin title={intl.formatMessage(messages.product_title)} icon="bar_chart" desc="">
        <Grid container spacing={2}>
          <Grid item md={8} xs={12}>
            <ul className={classes.bigResume}>
              <li>

                <Typography variant="h6">
                  <span className={classes.pinkText} style={{color:"#FF1616"}}>{lead}</span>
                  <Typography>
                    LEADS
                  </Typography>
                </Typography>
              </li>
              <li>

                <Typography variant="h6">
                  <span className={classes.pinkText} style={{color:"#FE7E0F"}}>{prospect}</span>
                  <Typography>
                    PROSPECTS
                  </Typography>
                </Typography>
              </li>
              <li>

                <Typography variant="h6">
                  <span className={classes.pinkText} style={{color:"#87C830"}}>{consult}</span>
                  <Typography>
                    CONSULT
                  </Typography>
                </Typography>
              </li>
              <li>

                <Typography variant="h6">
                  <span className={classes.pinkText} style={{color:"#8E3CCB"}}>{close}</span>
                  <Typography>
                    CLOSE
                  </Typography>
                </Typography>
              </li>

            </ul>
            <div className={classes.chartWrap}>
              <div className={classes.chartFluid}>
                <ResponsiveContainer>
                  <BarChart
                    data={dataSales}
                  >
                    <XAxis dataKey="name" tickLine={false} />
                    <YAxis axisLine={false} tickSize={3} tickLine={false} tick={{ stroke: 'none' }} />
                    <CartesianGrid vertical={false} strokeDasharray="3 3" />
                    <CartesianAxis />
                    <Tooltip />
                    <Bar dataKey="Fashions" fill={color.primary} />
                    <Bar dataKey="Electronics" fill={color.secondary} />
                    <Bar dataKey="Toys" fill={color.third} />
                    <Bar dataKey="Vouchers" fill={color.fourth} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>
          </Grid>
          <Grid item md={4} xs={12}>
            <Typography className={classes.smallTitle} variant="button">
              SALES CAMPAIGN

            </Typography>
            <Divider className={classes.divider} />
            <Grid container className={classes.secondaryWrap}>
              <div style={{width:'40%'}}>

                <Typography  style={{marginTop:"35px", color:'grey'}}>
                  <Typography >
                    <strong>LEADS</strong>
                    <div style={{border:"1px solid grey", width:'100%'}}></div>
                    {lead}
                  </Typography>

                </Typography>
                <Typography  style={{marginTop:"35px", color:'grey'}}>
                  <Typography  >
                    <strong> PROSPECTS</strong>
                    <div style={{border:"1px solid grey", width:'115%'}}></div>
                    {prospect}
                  </Typography>

                </Typography>
                <Typography  style={{marginTop:"15px", color:'grey'}}>
                  <Typography  >
                    <strong> CONSULT</strong>
                    <div style={{border:"1px solid grey", width:'128%'}}></div>
                    {consult}
                  </Typography>

                </Typography>
                <Typography  style={{marginTop:"15px", color:'grey'}}>
                  <Typography  >
                    <strong>CLOSED</strong>
                    <div style={{border:"1px solid grey", width:'138%'}}></div>
                    {close}
                  </Typography>

                </Typography>
              </div>
              <div style={{width:'60%'}}>
                <img src='images/campaign.png'  width={300} height={300} className={classes.img} alt='Campaign' />
              </div>

            </Grid>
          </Grid>
        </Grid>
      </PapperBlock>
    );
  }
}

SalesChartWidget.propTypes = {
  classes: PropTypes.object.isRequired,
  intl: intlShape.isRequired
};

export default withStyles(styles)(injectIntl(SalesChartWidget));
