import React, { PureComponent } from 'react';
import PropTypes from 'prop-types';
import CountUp from 'react-countup';
import { withStyles } from '@material-ui/core/styles';
import Typography from '@material-ui/core/Typography';
import TrendingUp from '@material-ui/icons/TrendingUp';
import TrendingDown from '@material-ui/icons/TrendingDown';
import TrendingFlat from '@material-ui/icons/TrendingFlat';
import Avatar from '@material-ui/core/Avatar';
import green from '@material-ui/core/colors/green';
import red from '@material-ui/core/colors/red';
import Paper from '@material-ui/core/Paper';

const styles = theme => ({
  root: {
    flexGrow: 1,
    justifyContent: 'space-between',
    height: 130,
    overflow: 'hidden',
    marginBottom: 6,
    display: 'flex',
    flexDirection: 'column',
    background: theme.palette.background.papaer,
    [theme.breakpoints.up('sm')]: {
      marginBottom: -1,
    },
    [theme.breakpoints.down('xs')]: {
      flexDirection: 'column',
    },
    '& > *': {
      padding: '0 5px'
    }
  },
  header: {
    display: 'flex',
    alignItems: 'center',
    padding: 10,
  },
  title: {
    color: theme.palette.text.primary,
    fontSize: 16,
    fontWeight: 400,
    flex: 1,
    '& span': {
      fontWeight: 'bold',
      fontSize: 12,
      '& svg': {
        width: 16
      }
    }
  },
  extend: {
    color: theme.palette.common.white,
    fontSize: 12,
    padding: theme.spacing(0.5),
    position: 'relative',
    zIndex: 1,
    marginBottom: 4
  },
  counter: {
    color: theme.palette.text.secondary,
    fontSize: 36,
    fontWeight: 500
  },
  content: {
    textAlign: 'right',
    position: 'relative'
  },
  up: {
    color: green[500],
    '& svg': {
      fill: green[500],
    }
  },
  down: {
    color: red[500],
    '& svg': {
      fill: red[500],
    }
  },
  flat: {
    color: theme.palette.divider,
    '& svg': {
      fill: theme.palette.divider,
    }
  },
  avatar: {
    width: 40,
    height: 40,
    marginRight: theme.spacing(0.5),
  },
  decoration: {
    borderRadius: '50%',
    width: '200%',
    position: 'absolute',
    height: 260,
    left: '-50%',
    top: -20
  }
});

class CounterTrading extends PureComponent {
  render() {
    const {
      classes,
      color,
      start,
      end,
      duration,
      logo,
      title,
      children,
      unitBefore,
      unitAfter,
      position,
      value,
      lowest,
      secondary,
      highest,
    } = this.props;
    return (
      <Paper className={classes.root}>
        <header className={classes.header}>
          <Avatar
            alt="bitcoin"
            src={logo}
            className={classes.avatar}
          />
          <div className={classes.title}>
            <Typography className={classes.title} noWrap variant="subtitle1">{title}</Typography>
          </div>
          <Typography className={classes.counter}>
            { unitBefore }
            <CountUp start={start} end={end} duration={duration} useEasing   decimals={2}       />
            { unitAfter }
          </Typography>
        </header>
        <div className={classes.content} style={{ backgroundColor: color }}>
          <span className={classes.decoration} style={{ backgroundColor: color }} />
          <div className={classes.extend}>
            <ul>
              <li>
                <h3>{secondary}: $&nbsp;
                  {lowest}</h3>
              </li>

            </ul>
          </div>
          {children}
        </div>
      </Paper>
    );
  }
}

CounterTrading.propTypes = {
  classes: PropTypes.object.isRequired,

};

CounterTrading.defaultProps = {
  unitBefore: '',
  unitAfter: '',
};

export default withStyles(styles)(CounterTrading);
