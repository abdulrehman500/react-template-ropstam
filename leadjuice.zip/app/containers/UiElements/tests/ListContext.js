import React from 'react';

/**
 * @ignore - internal component.
 */
const ListContext = React.createContext({});

export default ListContext;
