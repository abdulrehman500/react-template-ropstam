export const CLOSE_NOTIF = 'CLOSE_NOTIF';
export const SHOW_NOTIF = 'SHOW_NOTIF';
