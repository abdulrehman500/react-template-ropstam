import axios from "axios";


export default axios.create({
  baseURL: 'http://leadjuice.ropstambpo.com:3000/api',
  headers: {
    'Accept':'application-json',
    "Content-type": "application/json",

  }
});


