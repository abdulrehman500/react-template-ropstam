const jwt = require('jsonwebtoken');
const User = require('../models/user');


module.exports=async function (req, res, next){
  const token = req.header('Authorization');
  if(!token)
    return res.status(200).send({data:[],meta:{msg:'Authorization Token Error',status:401,error:null}});

  try{

    const { _id,exp } = await jwt.verify(token, process.env.TOKEN_SECREAT);
 //   console.log(_id);
    // Check if token has expired
    if (exp < Date.now().valueOf() / 1000) {
      return res.status(200).send({data:[],meta:{msg:'JWT token has expired, please login to obtain a new one',status:401,error:null}});


    }

  //  req.io = io;


    res.locals.loggedInUser = await User.findById(_id);

    next();
  }
  catch(err){
    //console.log(err)

    return res.send({data:null,meta:{msg:'Invalid Token',status:401,error:null}});

  }
}
