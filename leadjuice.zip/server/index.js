/* eslint consistent-return:0 import/order:0 */

const express = require('express');
const logger = require('./logger');
const favicon = require('serve-favicon');
const path = require('path');
const rawicons = require('./rawicons');
const rawdocs = require('./rawdocs');
const argv = require('./argv');
const port = require('./port');
const mongoose = require('mongoose');
const apiRoutes = require('./routes/api');
const bodyParser = require('body-parser');
const dotenv= require('dotenv');
let cors = require('cors');
var dotenvExpand = require('dotenv-expand');
var schedule = require('node-schedule');

const feathers = require('@feathersjs/feathers');

const memory = require('feathers-memory');
const PushNotifications = require('node-pushnotifications');

const ClinicFunnel = require('./models/clinicFunnels');
const Customers = require('./models/customer');
var fs = require('fs');

const https = require('https');


  const { steps } = require('./controllers/schedular');
const settings = {
  web: {
    vapidDetails: {
      subject: 'mailto@me.net',
      publicKey: '< URL Safe Base64 Encoded Public Key >',
      privateKey: '< URL Safe Base64 Encoded Private Key >'
    },
    gcmAPIKey:
      'AAAA9U3NkO8:APA91bE9XnPD1WQGYle0dbJs6KO6HmAq_73f_z2PHoPr3sbRovXbn9q-PyJAKYlxgNI88rBpTzNWCXRuxhX9FcwbDBhT4h0BAiJr4BiEx8uSkWHXM92q04Q6cydK-dHGSnR20bsgH0Lg'
    // TTL: 2419200
    // headers: { }
    // contentEncoding: '< Encoding type, e.g.: aesgcm or aes128gcm >'
  }
};


const push = new PushNotifications(settings);


const setup = require('./middlewares/frontendMiddleware');
var myEnv=dotenv.config();
dotenvExpand(myEnv);
steps();
const isDev = process.env.NODE_ENV !== 'production';
const ngrok = (isDev && process.env.ENABLE_TUNNEL) || argv.tunnel
  ? require('ngrok')
  : false;
const { resolve } = require('path');
//const app = express();

const app = require("express")();

/*app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));*/
app.use(express.json());

app.use(cors());



/*
app.use(upload.array());
app.use(express.static('public'))
*/







app.use('/api', apiRoutes);

app.post("/webhook", (req, res) => {
  console.log(req.body) // Call your action on the request here
  return  res.status(200).send({
    name:"ather"
  }); // Responding is important
});
app.post("/funnel_webhooks/test", (req, res) => {
  console.log(req.body) // Call your action on the request here
  console.log('Web Hook') // Call your action on the request here
  return  res.status(200).send({
    name:"ather"
  }); // Responding is important
});
app.post("/webhook/:id",async (req, res) => {


  try {

    const funnel=await ClinicFunnel.findById(mongoose.Types.ObjectId(req.params.id));
    console.log(req.params.id);
    if(!funnel)
      return res.status(404).json({ data:null,meta:{message:'Error',status:404,errors: null }});



    req.body.staff_id=funnel.staff;
    req.body.list_id=funnel.list;
    req.body.type=mongoose.Types.ObjectId('5f0703b4e43ca83bd84ebc2c');
    const cust= new Customers (req.body);

    var saveCust = await cust.save();


    return  res.json({data:funnel,meta:{message:"Record Found",status:200,errors:null}});
  }catch (err){
    return res.status(404).json({ data:null,meta:{message:'Error',status:404,errors: err }});

  }


});

mongoose.connect('mongodb+srv://admin:admin@cluster0.ufgst.mongodb.net/lead-juice?retryWrites=true&w=majority',{ useNewUrlParser: true });
let db=mongoose.connection;
db.once('open',function () {
    console.log('Connected DB');
});

db.on('err',function (err) {
console.log(err);
})


// If you need a backend, e.g. an API, add your custom backend-specific middleware here
// app.use('/api', myApi);
// Load material icons


app.use('/api/icons', (req, res) => {
  res.json({
    records: [
      { source: rawicons(req.query) }
    ]
  });
});

// Load code preview
app.use('/api/docs', (req, res) => {
  res.json({
    records: [
      { source: rawdocs(req.query) }
    ]
  });
});






















app.use('/', express.static('public', { etag: false }));
app.use(favicon(path.join('public', 'favicons', 'favicon.ico')));

// In production we need to pass these values in instead of relying on webpack
setup(app, {
  outputPath: resolve(process.cwd(), 'build'),
  publicPath: '/',
});

// get the intended host and port number, use localhost and port 3000 if not provided
const customHost = argv.host || process.env.HOST;
console.log('Port'+port);
const host = customHost || null; // Let http.Server use its default IPv6/4 host
const prettyHost = 'leadjuice.ropstambpo.com' || 'localhost';

// use the gzipped bundle
app.get('*.js', (req, res, next) => {
  req.url = req.url + '.gz'; // eslint-disable-line
  res.set('Content-Encoding', 'gzip');
  next();
});

// Start your app.

/*var server = https.createServer({
    key: fs.readFileSync('./server/key.pem'),
    cert: fs.readFileSync('./server/cert.pem'),
    passphrase: 'Ather'
}, app).listen(3000);*/
/*app.listen(port, host, async err => {


  if (err) {
    return logger.error(err.message);
  }

  // Connect to ngrok in dev mode
  if (ngrok) {
    let url;
    try {
      url = await ngrok.connect(port);
    } catch (e) {
      return logger.error(e);
    }
    logger.appStarted(port, prettyHost, url);
  } else {
    logger.appStarted(port, prettyHost);
  }
});*/

var server=app.listen(port, host, async err => {


  if (err) {
    return logger.error(err.message);
  }

  // Connect to ngrok in dev mode
  if (ngrok) {
    let url;
    try {
      url = await ngrok.connect(port);
    } catch (e) {
      return logger.error(e);
    }
    logger.appStarted(port, prettyHost, url);
  } else {
    logger.appStarted(port, prettyHost);
  }
});

const socket = require("socket.io");

/*var http = require('http').Server(app);
var io = require('socket.io')(http);
io.on('connection', () =>{
  console.log('a user is connected')
})*/
var io=socket(server)
app.io = io;

app.use(function(req,res,next){
  req.io = io;
  next();
})
//app.io.attach(server);
/*app.use('/api',function(req,res,next){
  console.log(io)
  req.io = io;
  next();
});*/
io.emit('chat-message','Hello World React ')

io.on("connection", function(soc) {

  //console.log('Socket')


  soc.on('chat-message', data=>{
    console.log(123);
    console.log(data)
  })

});


