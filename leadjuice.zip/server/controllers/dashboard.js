const Clinic =  require('../models/clinic');
const ClinicSpent =  require('../models/clinicSpent');

const Customers = require('../models/customer');
const Settings = require('../models/settings');
const Staff = require('../models/staff');
const CustomerTypes = require('../models/customerTypes');
const {check , validationResult} = require('express-validator');
var mongoose = require('mongoose');

exports.getDasboardData = async (req, res) => {


  // try {
  if(res.locals.loggedInUser.role=='staff')
  {
    var staff= await Staff.findOne({user:res.locals.loggedInUser._id});
    // return res.status(200).json({data:staff,meta:{message:"Record Found",status:200,errors:null}});
    if(staff)
      req.params.sid=staff._id;
    else
      return res.json({data:null,meta:{message:"Record Not Found",status:200,errors:null }});

  }

//  let pquery = Customers.find({type:mongoose.Types.ObjectId('5f0703b4e43ca83bd84ebc2c')});
    let pquery = Customers.aggregate();
    pquery.match({type:mongoose.Types.ObjectId('5f0703b4e43ca83bd84ebc2d')});

  if(req.params.sid) {
    pquery.match({ staff_id: mongoose.Types.ObjectId(req.params.sid) });
  }
  const pros=await pquery.exec();
  

//  let lquery = Customers.find({type:mongoose.Types.ObjectId('5f0703b4e43ca83bd84ebc2c')});
      let lquery = Customers.aggregate();

      lquery.match({type:mongoose.Types.ObjectId('5f0703b4e43ca83bd84ebc2d')});

  if(req.params.sid) {
    lquery.match({ staff_id: mongoose.Types.ObjectId(req.params.sid) });
  }
  const lead=await lquery.exec();

 // let cquery = Customers.find({type:mongoose.Types.ObjectId('5f0703b4e43ca83bd84ebc2e')});
        let cquery = Customers.aggregate();

    cquery.match({type:mongoose.Types.ObjectId('5f0703b4e43ca83bd84ebc2e')});

  if(req.params.sid) {
    cquery.match({ staff_id: mongoose.Types.ObjectId(req.params.sid) });
  }
  const consult=await cquery.exec();

  //let clquery = Customers.find({type:mongoose.Types.ObjectId('5f0703b4e43ca83bd84ebc2f')});
          let clquery = Customers.aggregate();

      clquery.match({type:mongoose.Types.ObjectId('5f0703b4e43ca83bd84ebc2f')});

  if(req.params.sid) {
    clquery.match({ staff_id: mongoose.Types.ObjectId(req.params.sid) });
  }
  const close=await clquery.exec();

  let revq = Customers.aggregate();
  revq.group({ _id: null, price: { $sum: "$price" } });
  if(req.params.sid) {
    revq.match({ staff_id: mongoose.Types.ObjectId(req.params.sid) });
  }
  const rev=await revq.exec();
  //return res.json({data:rev,meta:{message:"Record Not Found",status:200,errors:null }});
  let coquery = Clinic.find();

  const company=await coquery.count();


  var data={
    'prospect':pros.length,
    'lead':lead.length,
    'consult':consult.length,
    'close':close.length,
    'revenue':rev.length,
    'company':company.length,
    'contacts':pros.length+lead.length+consult.length+close.length,

  }

  res.json({data:data,meta:{message:"Record Found",status:200,errors:null }});
  /*  }catch (err){
      return res.status(200).json({ data:null,meta:{message:'Error',status:201,errors: err }});


    }*/
}
exports.getPaymentData = async (req, res) => {


  // try {
  if(res.locals.loggedInUser.role=='staff')
  {
    var staff= await Staff.findOne({user:res.locals.loggedInUser._id});
    // return res.status(200).json({data:staff,meta:{message:"Record Found",status:200,errors:null}});
    if(staff)
      req.params.sid=staff._id;
    else
      return res.json({data:null,meta:{message:"Record Not Found",status:200,errors:null }});

  }

  let pquery = Customers.aggregate();
  pquery.match({ type: mongoose.Types.ObjectId('5f0703b4e43ca83bd84ebc2c') });
  pquery.group({ _id: null, price: { $sum: "$price" },count: { $sum: 1 } });

  if(req.params.sid) {
    pquery.match({ staff_id: mongoose.Types.ObjectId(req.params.sid) });
  }
  const pros=await pquery.exec();

  let lquery = Customers.aggregate();
  lquery.match({ type: mongoose.Types.ObjectId('5f0703b4e43ca83bd84ebc2d') });
  lquery.group({ _id: null, price: { $sum: "$price" },count: { $sum: 1 } });

  if(req.params.sid) {
    lquery.match({ staff_id: mongoose.Types.ObjectId(req.params.sid) });
  }
  const lead=await lquery.exec();

  let cquery = Customers.aggregate();
  cquery.match({ type: mongoose.Types.ObjectId('5f0703b4e43ca83bd84ebc2e') });
  cquery.group({ _id: null, price: { $sum: "$price" },count: { $sum: 1 } });


  if(req.params.sid) {
    cquery.match({ staff_id: mongoose.Types.ObjectId(req.params.sid) });
  }
  const consult=await cquery.exec();


  let clquery = Customers.aggregate();
  clquery.match({ type: mongoose.Types.ObjectId('5f0703b4e43ca83bd84ebc2f') });
  clquery.group({ _id: null, price: { $sum: "$price" },count: { $sum: 1 } });


  if(req.params.sid) {
    clquery.match({ staff_id: mongoose.Types.ObjectId(req.params.sid) });
  }
  const close=await clquery.exec();



  let revq = Customers.aggregate();
  revq.group({ _id: null, price: { $sum: "$price" } });
  if(req.params.sid) {
    revq.match({ staff_id: mongoose.Types.ObjectId(req.params.sid) });
  }
  const rev=await revq.exec();

  let cs = ClinicSpent.aggregate();
  cs.group({ _id: null, price: { $sum: "$price" } });
  if(req.params.sid) {
    cs.match({ staff_id: mongoose.Types.ObjectId(req.params.sid) });
  }
  const spent=await cs.exec();
  //return res.json({data:rev,meta:{message:"Record Not Found",status:200,errors:null }});
  let coquery = Clinic.find();

  const company=await coquery.count();


  var data={
    'prospect':pros,
    'lead':lead,
    'consult':consult,
    'close':close,
    'spend':spent,
    'company':company,
    'contacts':pros+lead+consult,

  }

  res.json({data:data,meta:{message:"Record Found",status:200,errors:null }});
  /*  }catch (err){
      return res.status(200).json({ data:null,meta:{message:'Error',status:201,errors: err }});


    }*/
}
exports.getHotLeads = async (req, res) => {


  try {
    if(res.locals.loggedInUser.role=='staff')
    {
      var staff= await Staff.findOne({user:res.locals.loggedInUser._id});
      // return res.status(200).json({data:staff,meta:{message:"Record Found",status:200,errors:null}});
      if(staff)
        req.params.sid=staff._id;
      else
        return res.json({data:null,meta:{message:"Record Not Found",status:200,errors:null }});

    }
    let query = Customers.aggregate();

    if(req.params.sid) {
      // console.log(req.params);
      query.match({ staff_id: mongoose.Types.ObjectId(req.params.sid) });
    }
    if(req.params.type) {
      // console.log(req.params);
      let cType =await CustomerTypes.findOne({name:req.params.type});

      query.match({ type: mongoose.Types.ObjectId(cType._id) });
    }
    if(req.params.id) {
      // console.log(req.params);
      query.match({ list_id: mongoose.Types.ObjectId(req.params.id) });
    }
    query.lookup({
        from: "staffs",
        localField: "staff_id",
        foreignField: "_id",
        as: "staff",
      }
    );
    query.lookup({
        from: "lists",
        localField: "list_id",
        foreignField: "_id",
        as: "list_name",
      }
    );
    query.lookup({
        from: "customertypes",
        localField: "type",
        foreignField: "_id",
        as: "clientType",
      }
    );
    query.project(
      {
        _id:"$_id",
        first_name:{ $ifNull: [ "$first_name",null ] },
        last_name:{ $ifNull: [ "$last_name",null ] },
        phone:{ $ifNull: [ "$phone",null] },
        email:{ $ifNull: [ "$email", null ] },
        address:{ $ifNull: [ "$address", null ] },
        gender:{ $ifNull: [ "$gender", "Male" ] },
        city:{ $ifNull: [ "$city", null ] },
        //    label:{ $ifNull: [ "$label", null ] },
        list_name:{ $ifNull:[
            {
              $arrayElemAt: [ {
                $map: {
                  input: "$list_name",
                  as: "l",
                  in: { $ifNull: [ "$$l.name", null ] }
                }
              }, 0 ]
            }

            , null ] },
        type:{ $ifNull:[
            {
              $arrayElemAt: [ {
                $map: {
                  input: "$clientType",
                  as: "e",
                  in: {name:{ $ifNull: [ "$$e.name", null ] },
                    _id:{ $ifNull: [ "$$e._id", null ] }}
                }
              }, 0 ]
            }

            , "Prospect" ] },


        time:{ $ifNull: [ "$time", "Today" ] },
        staff:{
          $arrayElemAt: [ {
            $map: {
              input: "$staff",
              as: "e",
              in:
                {name: { $concat: [ { $ifNull: [ "$$e.first_name", '' ] }, " ",{ $ifNull: [ "$$e.last_name", '' ] }  ] }}
            }
          }, 0 ]
        },



      }

    );

    const result=await query.limit(5).exec();

    res.json({data:result,meta:{message:"Record Found",status:200,errors:null }});
  }catch (err){
    return res.status(200).json({ data:null,meta:{message:'Error',status:201,errors: err }});

  }
}

exports.getSettings = async (req, res) => {


  try {


    var data={
      'prospect':2,
      'lead':3,
      'consult':5,
      'close':4,
      'revenue':4,

    }

    res.json({data:data,meta:{message:"Record Found",status:200,errors:null }});
  }catch (err){
    return res.status(200).json({ data:null,meta:{message:'Error',status:201,errors: err }});


  }
}
