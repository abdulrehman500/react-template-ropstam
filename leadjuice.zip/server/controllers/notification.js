const Notification = require('../models/notification');
const {check , validationResult} = require('express-validator');
var mongoose = require('mongoose');

exports.getAll = async (req, res) => {


  // try {
  var  noti=[{
    _id:"1",
    title:"Lead Added",
    message:"New Lead Assigned to your account",
    time:"1h ago",read:true
  },{
    _id:"2",

    title:"Lead Added",
    message:"New Lead Assigned to your account",
    time:"3h ago",read:false
  }
    ,{
      _id:"3",

      title:"Lead Added",
      message:"New Lead Assigned to your account",
      time:"4h ago",read:true
    },{
      _id:"4",

      title:"Lead Added",
      message:"New Lead Assigned to your account",
      time:"2h ago",read:true
    },{
      _id:"5",

      title:"Lead Added",
      message:"New Lead Assigned to your account",
      time:"5h ago",read:false
    },{
      _id:"6",

      title:"Lead Added",
      message:"New Lead Assigned to your account",
      time:"6h ago",read:false
    },{
      _id:"7",

      title:"Lead Added",
      message:"New Lead Assigned to your account",
      time:"7h ago",read:false
    }];

  res.json({data:noti,meta:{message:"Record Found",status:200,errors:null}});
  /*  }catch (err){
      res.json({message:err})

    }*/
}
exports.sendNotification = async (req, res) => {


  // try {


  res.json({data:null,meta:{message:"Record Found",status:200,errors:null}});
  /*  }catch (err){
      res.json({message:err})

    }*/
}

