const Clinic = require('../models/clinic');
const ClinicFunnel = require('../models/clinicFunnels');
const {check , validationResult} = require('express-validator');
const jwt = require('jsonwebtoken');
const Staff = require('../models/staff');
const ClinicSpent = require('../models/clinicSpent');
const User = require('../models/user');
const sgMail = require('@sendgrid/mail');
var twilio = require('twilio');
let multer = require('multer');
var socket = require('socket.io-client')('http://192.168.1.123:3000');


const fs = require('fs')
const { promisify } = require('util')

const unlinkAsync = promisify(fs.unlink)

//var upload = multer({ dest: 'uploads/' } );

var mongoose = require('mongoose');
mongoose.set('useFindAndModify', false);

exports.getAllClinic = async (req, res) => {


 // try {
    const clinic =await Clinic.aggregate(
      [

        {
        $lookup: {
          from: "staffs",
          localField: "_id",
          foreignField: "clinic",
          as: "staff",
        },

      },

          {
            $project:{
              _id:"$_id",
              clinic_id:{ $ifNull: [ "$clinic_id", null ] },
              logo:{ $ifNull: [ "$logo",null ] },
              name:{ $ifNull: [ "$name",null ] },
              phone:{ $ifNull: [ "$phone",null] },
              email:{ $ifNull: [ "$email", null ] },
              address:{ $ifNull: [ "$address", null ] },
              status:{ $ifNull: [ "$status", false ] },



              staff_members:{$size:"$staff"}
             // students:"$staff"
            }
          },


      ])
    ;
    res.json({data:clinic,meta:{message:"Record Found",status:200,errors:null}});
/*  }catch (err){
    res.json({message:err})

  }*/
}

exports.addClinic = async (req, res) => {

  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    if(req.file)
    await unlinkAsync(req.file.path)

    return res.status(200)
      .json({
        data: null,
        meta: {
          message: 'Validation Error',
          status: 422,
          errors: errors.array()
        }
      });
  }

  if (req.file)
    req.body.logo = req.file.filename;

  try {
    const user = new User({
      first_name: req.body.name,
      email: req.body.email,
      role: "company",
      status: false
    });

    var saveUser = await user.save();


    req.body.user = saveUser._id;
    const cli = new Clinic(req.body);


    var saveClinic = await cli.save();

    req.body.clinic=saveClinic._id;
    const clis= new ClinicSpent(req.body);


    await clis.save();

    //  res.status(200).json(saveClinic);
    return res.status(200)
      .json({
        data: saveClinic,
        meta: {
          message: 'Added Successfully',
          status: 200,
          errors: null
        }
      });

  } catch (err) {
    return res.status(200)
      .json({
        data: null,
        meta: {
          message: 'Error',
          status: 200,
          errors: err
        }
      });

  }

}
exports.findClinic = async (req, res) => {


  //try {
  const cli=await Clinic.aggregate(
    [
      { "$match" : { _id :mongoose.Types.ObjectId(req.params.id) } },
      {
        $lookup: {
          from: "staffs",
          localField: "_id",
          foreignField: "clinic",
          as: "staff",
        },

      },

      {
        $project:{
          _id:"$_id",
          clinic_id:{ $ifNull: [ "$clinic_id", null ] },
          logo:{ $ifNull: [ "$logo", null ] },

          name:{ $ifNull: [ "$name",null ] },
          phone:{ $ifNull: [ "$phone",null] },
          email:{ $ifNull: [ "$email", null ] },
          address:{ $ifNull: [ "$address", null ] },
          city:{ $ifNull: [ "$city", null ] },
          state:{ $ifNull: [ "$state", null ] },
          zip:{ $ifNull: [ "$zip", null ] },
          spent:{ $ifNull: [ "$spent", null ] },
          status:{ $ifNull: [ "$status", false ] },
          email_setting:{$arrayElemAt: [ { $ifNull: [ "$emailSettings", null ] }, 0 ]},
          sms_setting:{$arrayElemAt: [ { $ifNull: [ "$twilioSettings", null ] }, 0 ]},



          staff_members:{$size:"$staff"}
          // students:"$staff"
        }
      },


    ]).limit(1);

  res.status(200).json({data:cli[0],meta:{message:"Record Found",status:200,errors:null}});

  /*  }catch (err){
      res.json({message:err})

    }*/
}
exports.deleteClinic = async (req, res) => {


  try {
    const cli=await Clinic.findByIdAndDelete(req.params.id);
    res.status(200).json({data:null,meta:{message:"Record Deleted",status:200,errors:null}});

  }catch (err){
    res.json({message:err})

  }
}
exports.updateClinic = async (req, res) => {





  try {

  const clinic = await Clinic.findById(req.params.id);
  const checkMail = await User.findOne({email:req.body.email});

    if(checkMail)
  if (clinic.user.toString() != checkMail._id.toString())
    return res.status(200).json({ data:null,meta:{message:'Email Already Exists',status:202,errors: null }});

console.log(req.file)

  if (req.file) {
      console.log(123);
      req.body.logo = req.file.filename;

    if (clinic.logo)
        await unlinkAsync('public/clinic_images/' + clinic.logo)
    }
    
    console.log(req.body)

    const cli=await Clinic.findOneAndUpdate({_id:req.params.id},



      {$set:req.body}
    );

    req.body.clinic=req.params.id;
    const clis= new ClinicSpent(req.body);
    await clis.save();

  var id= mongoose.Types.ObjectId();
  if(cli.user) {
    var query = { _id: cli.user };
  }
  else {


    var query = { _id: id };

    const cli1=await Clinic.findByIdAndUpdate(req.params.id, {user:id} );
  }

  //  var query = {_id:cli.user};
    var update = {first_name:req.body.name,email:req.body.email,role:"company",status:false};
    var options = {
      // Return the document after updates are applied
      new: true,
      // Create a document if one isn't found. Required
      // for `setDefaultsOnInsert`
      upsert: true,
      setDefaultsOnInsert: true
    };
    const user=await User.findOneAndUpdate(query,update,options);


    return res.status(200).json({ data:null,meta:{message:'Updated Successfully',status:200,errors: null }});

  }catch (err){
    return res.status(200).json({ data:null,meta:{message:'Error',status:201,errors: err }});


  }
}
exports.updateSMS = async (req, res) => {


  try {
    var accountSid = req.body.api_key; // Your Account SID from www.twilio.com/console
    var authToken = req.body.auth_token;   // Your Auth Token from www.twilio.com/console

    var twilio = require('twilio');
    var client = new twilio(accountSid, authToken);
const cli=await Clinic.updateOne({_id:req.params.id},



          {$set:{ twilioSettings: req.body }}
        );
        return res.status(200).json({ data:null,meta:{message:'Updated Successfully',status:200,errors: null }});

    var response =await client.messages
      .create({
        body: 'Test Message of Twilio LeadJuice Integration',
        from: req.body.from,
        to:  req.body.test_number
      })
      .then(message = async () =>
      {
        const cli=await Clinic.updateOne({_id:req.params.id},



          {$set:{ twilioSettings: req.body }}
        );
        return res.status(200).json({ data:null,meta:{message:'Updated Successfully',status:200,errors: null }});
      })
      .catch(e => {
        return res.status(200).json({data:null,meta:{message:e.message,status:e.code,errors:null}});

      })

      .done();


  }catch (err){
    return res.status(200).json({ data:null,meta:{message:'Invalid Credentials',status:201,errors: err }});


  }
}
exports.updateEmail = async (req, res) => {


  try {


    sgMail.setApiKey(req.body.api_key);

    const msg = {
      to: req.body.test_email,
      from: req.body.email,
      subject: 'Sending with Twilio LeadJuice Integration ',
      text: "Integration Successfull",
    };

    try {
     // var response =await sgMail.send(msg);
      const cli=await Clinic.updateOne({_id:req.params.id},



        {$set:{ emailSettings: req.body }}
      );
      return res.status(200).json({ data:null,meta:{message:'Updated Successfully',status:200,errors: null }});

    }catch (err){
      return res.status(200).json({ data:null,meta:{message:err.message,status:err.code,errors: null }});

    }


  }catch (err){
    return res.status(200).json({ data:null,meta:{message:'Error',status:201,errors: err }});


  }
}

exports.myClinic = async (req, res) => {



  try {

    if(res.locals.loggedInUser.role=='staff')
    {
      var staff= await Staff.findOne({user:res.locals.loggedInUser._id});
      // return res.status(200).json({data:staff,meta:{message:"Record Found",status:200,errors:null}});
      if(staff)
        req.body.clinic=staff.clinic;
      else
        return res.json({data:null,meta:{message:"Record Not Found",status:200,errors:null }});

    }


    const cli=await Clinic.aggregate(
      [
        { "$match" : { _id :mongoose.Types.ObjectId(req.body.clinic) } },
        {
          $lookup: {
            from: "staffs",
            localField: "_id",
            foreignField: "clinic",
            as: "staff",
          },

        },

        {
          $project:{
            _id:"$_id",
            clinic_id:{ $ifNull: [ "$clinic_id", null ] },
            logo:{ $ifNull: [ "$logo", null ] },

            name:{ $ifNull: [ "$name",null ] },
            phone:{ $ifNull: [ "$phone",null] },
            email:{ $ifNull: [ "$email", null ] },
            address:{ $ifNull: [ "$address", null ] },
            city:{ $ifNull: [ "$city", null ] },
            state:{ $ifNull: [ "$state", null ] },
            zip:{ $ifNull: [ "$zip", null ] },
            email_setting:{$arrayElemAt: [ { $ifNull: [ "$emailSettings", null ] }, 0 ]},
            sms_setting:{$arrayElemAt: [ { $ifNull: [ "$twilioSettings", null ] }, 0 ]},



            staff_members:{$size:"$staff"}
            // students:"$staff"
          }
        },


      ]).limit(1);
if(cli[0])
  res.status(200).json({data:cli[0],meta:{message:"Record Found",status:200,errors:null}});
else
  res.status(200).json({data:null,meta:{message:"Record Not Found",status:200,errors:null}});

  }catch (err){
    return res.status(200).json({ data:null,meta:{message:'Error',status:201,errors: err }});


  }
}


exports.editMyClinic = async (req, res) => {


//  try {

  

    if(res.locals.loggedInUser.role=='staff')
    {
      var staff= await Staff.findOne({user:res.locals.loggedInUser._id});
      // return res.status(200).json({data:staff,meta:{message:"Record Found",status:200,errors:null}});
      if(staff)
        req.body.clinic=staff.clinic;
      else
        return res.json({data:null,meta:{message:"Record Not Found",status:200,errors:null }});

    }

  const clinic = await Clinic.findById(req.body.clinic);

    const checkMail = await User.findOne({email:req.body.email});
    if(checkMail)
      if (clinic.user.toString() != checkMail._id.toString())
        return res.status(200).json({ data:null,meta:{message:'Email Already Exists',status:202,errors: null }});



    const cli=await Clinic.updateOne({_id:mongoose.Types.ObjectId(req.body.clinic)},



      {$set:req.body}
    );
    return res.status(200).json({ data:null,meta:{message:'Updated Successfully',status:200,errors: null }});

/*  }catch (err){
    return res.status(200).json({ data:null,meta:{message:'Error',status:201,errors: err }});


  }*/
}
exports.editMyClinicSMS = async (req, res) => {


  try {
    if(res.locals.loggedInUser.role=='staff')
    {
      var staff= await Staff.findOne({user:res.locals.loggedInUser._id});
      // return res.status(200).json({data:staff,meta:{message:"Record Found",status:200,errors:null}});
      if(staff)
        req.body.clinic=staff.clinic;
      else
        return res.json({data:null,meta:{message:"Record Not Found",status:200,errors:null }});

    }

    const cli=await Clinic.updateOne({_id:req.body.clinic},



      {$set:{ twilioSettings: req.body }}
    );
    return res.status(200).json({ data:null,meta:{message:'Updated Successfully',status:200,errors: null }});

  }catch (err){
    return res.status(200).json({ data:null,meta:{message:'Error',status:201,errors: err }});


  }
}
exports.editMyClinicEmail = async (req, res) => {


  try {

    if(res.locals.loggedInUser.role=='staff')
    {
      var staff= await Staff.findOne({user:res.locals.loggedInUser._id});
      // return res.status(200).json({data:staff,meta:{message:"Record Found",status:200,errors:null}});
      if(staff)
        req.body.clinic=staff.clinic;
      else
        return res.json({data:null,meta:{message:"Record Not Found",status:200,errors:null }});

    }
    const cli=await Clinic.updateOne({_id:req.body.clinic},



      {$set:{ emailSettings: req.body }}
    );
    return res.status(200).json({ data:null,meta:{message:'Updated Successfully',status:200,errors: null }});

  }catch (err){
    return res.status(200).json({ data:null,meta:{message:'Error',status:201,errors: err }});


  }
}

exports.addClinicFunnel = async (req, res) => {

  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(200).json({ data:null,meta:{message:'Validation Error',status:422,errors: errors.array() }});
  }
  try {
req.body.clinic=req.params.id;
    const cli= new ClinicFunnel (req.body);



    var saveClinic = await cli.save();
    //  res.status(200).json(saveClinic);
    return res.status(200).json({ data:saveClinic,meta:{message:'Added Successfully',status:200,errors: null }});

  }catch (err){
    res.json({message:err})

  }
}
exports.getClinicFunnel = async (req, res) => {


  try {

    const funnel=await ClinicFunnel.find({clinic:req.params.id}).populate('staff', '_id first_name last_name').populate('list', 'name');


    res.json({data:funnel,meta:{message:"Record Found",status:200,errors:null}});
  }catch (err){
    return res.status(200).json({ data:null,meta:{message:'Error',status:201,errors: err }});

  }
}
