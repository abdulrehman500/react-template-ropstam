
const axios = require('axios');
var FormData = require('form-data');

exports.findFunnel = async (req, res) => {


  try {
    var data = new FormData();

    var config = {
      method: 'get',
      url: 'https://api.clickfunnels.com/api/attributes/funnels.json',
      headers: {
        "access_token": "0eeec59239a6c65673e5fbe20bc3574f",
        "token_type":"bearer",
        "scope":"public"
      },
      data : data
    };

    axios(config)
      .then(function (response) {

        console.log(JSON.stringify(response.data));
        console.log('success');
      })
      .catch(function (error) {
        console.log(error);
        console.log('error');

      });
    return res.json(data.getHeaders());


  }catch (err){
    return res.status(200).json({ data:null,meta:{message:'Error',status:201,errors: err }});

  }
}
