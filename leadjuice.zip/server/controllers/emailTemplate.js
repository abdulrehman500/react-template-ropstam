const Template = require('../models/emailTemplates');
const {check , validationResult} = require('express-validator');
var mongoose = require('mongoose');

exports.addTemplate = async (req, res) => {

  //  delete req.body.template;

  // console.log(req.body.templateHtml);

  req.body.templateHtml = req.body.templateHtml.replace(/\r?\n|\r/g, " ");

  const cust= new Template (req.body);


  try {
    var saveCust = await cust.save();
    return res.status(200).json({ data:null,meta:{message:'Added Successfully',status:200,errors: null }});
  }catch (err){
    return res.status(200).json({ data:null,meta:{message:'Error',status:201,errors: err }});

  }
}
exports.allTemplate = async (req, res) => {


  try {
    const list =await Template.find().select('name');

    return res.status(200).json({ data:list,meta:{message:'Record Found',status:200,errors: null }});
  }catch (err){
    return res.status(200).json({ data:null,meta:{message:'Error',status:201,errors: err }});

  }
}
exports.getTemplate = async (req, res) => {


  try {
    const list =await Template.findById(req.params.id);

    return res.status(200).json({ data:list,meta:{message:'Record Found',status:200,errors: null }});
  }catch (err){
    return res.status(200).json({ data:null,meta:{message:'Error',status:201,errors: err }});

  }
}

exports.updateTemplate = async (req, res) => {


  try {
    const cli=await Template.updateOne({_id:req.params.id},



      {$set:req.body }
    );
    return res.status(200).json({ data:null,meta:{message:'Updated Successfully',status:200,errors: null }});

  }catch (err){
    return res.status(200).json({ data:null,meta:{message:'Error',status:201,errors: err }});


  }
}
