var schedule = require('node-schedule');
const Customers = require('../models/customer');
const Funnel = require('../models/funnel');
const funnelDetail = require('../models/funnelDetail');
const funnelTrack= require('../models/funnelTrack');
var mongoose = require('mongoose');
var twilio = require('twilio');
const sgMail = require('@sendgrid/mail');
const moment = require('moment');

console.log('Steps');


exports.customers = async (req, res) => {
  console.log('In Function');

  const staff=await Customers.findById('5f06bf77add054bc3c4e9773').populate({
    path: 'staff_id',
    select: '_id first_name',

  });
  console.log(staff.staff_id._id)
  const funnel=await Funnel.find({staff:staff.staff_id._id}).exec(async function(err, docs)
  {
    await funnelDetail.find({finnel:docs._id}).exec(function(err1, docs1)
    {


    });

  });

  res.json({data:funnel,meta:{message:"Record Found",status:200,errors:null }});


}

const sendSms =async (to) => {
  var accountSid = process.env.TWILIO_SID; // Your Account SID from www.twilio.com/console
  var authToken = process.env.TWILIO_AUTH;   // Your Auth Token from www.twilio.com/console

  var twilio = require('twilio');
  var client = new twilio(accountSid, authToken);

  await client.messages
    .create({
      body: 'Test Message From Lead Juice',
      from: '+13433126182',
      to: to
    })
    .then(message => console.log(message))
    .done();
  // console.log('Lead Juice');
}
const sendEmail =(to,subject,message) => {
  sgMail.setApiKey(process.env.SENDGRID_API_KEY);

  const msg = {
    to: to,
    from: 'do-not-reply@ropstam.com',
    subject: subject,
    text: message,
  };
  sgMail.send(msg);


}


exports.steps = async (req, res) => {
  console.log('In Function');
  // test(1,3);

  try {
    if(true) {
      j = schedule.scheduleJob(' * * * * *', async function () {
        let j1,j2;

        var staff = mongoose.Types.ObjectId('5efdb5f8b1da0d07b0edb6f8');

        const funnelQuery = await Funnel.find({
          staff: staff
        });
        for await  (const funnel of funnelQuery) {
          // console.log('Funnel List' + funnel._id);

          const detailQuery = await funnelDetail.find({ funnel: funnel._id });

          for await  (const detail of detailQuery) {
            //    console.log('Detail List' + detail._id);
            const customerQuery = await Customers.find({
              staff_id: staff,
              type: detail.customer_type
            });
            //   console.log('Detail List Customers' + customerQuery.length);

            for (const customer of customerQuery) {
              //  console.log('Customer ' + customer._id);

              const detailQuery = await funnelTrack.findOne({
                funnelStep: detail._id,
                customer: customer._id
              });

              //    console.log('Funnel Track');
              if (!detailQuery) {
                const checkExisting = await funnelTrack.findOne({
                  funnelStep: detail._id,
                  customer: customer._id,
                  status: false
                });
                if (!checkExisting) {
                  const oldCheck = await funnelTrack.findOne({
                    customer: customer._id
                  });
                  if(oldCheck)
                  {
                    var saveTrack = new funnelTrack({
                      funnelStep: detail._id,
                      customer: customer._id,
                      createdAt:oldCheck.createdAt
                    });
                    await saveTrack.save();

                  }
                  else {
                    var saveTrack = new funnelTrack({
                      funnelStep: detail._id,
                      customer: customer._id
                    });
                    await saveTrack.save();

                  }




                } else {
                  console.log('Run Old');
                  if(true) {
                    if (!checkExisting.status) {
                      //  console.log('cron');
                      var hours = 0;
                      var minutes = 0;
                      var days = 0;

                      // console.log('Time - ' + detail.duration_time);


                      var startTime = checkExisting.createdAt;

                      if (detail.duration_type == 'hours') {
                        startTime.setHours(startTime.getHours() + detail.duration_time);
                      } else if (detail.duration_type == 'minute') {
                        startTime.setMinutes(startTime.getMinutes() + detail.duration_time);
                      } else {
                        startTime.setHours(startTime.getHours() + detail.duration_time * 24);
                      }

                      //   console.log(startTime);

                      let endTime = new Date(startTime.getTime() + 1000);
                      //  console.log('Start Time 1 - '+startTime);
                      //     console.log('End Time 1 - '+endTime);

                      j1= schedule.scheduleJob('job1',startTime/*{
                    start: startTime,
                    end: endTime,
                    rule: '*!/1 * * * * *'
                  }*/, async function () {
                        console.log('Time for tea 2!' + startTime);

                        await funnelTrack.findByIdAndUpdate(checkExisting._id, { status: true })
                          .then(
                            sendEmail(customer.email)
                          );

                      });
                      //    j1.cancel();

                    } else {
                      //    console.log(detailQuery._id);
                      //   console.log('NE')
                    }
                  }
                }

                /*   */
              }
              else {
                if (!detailQuery.status) {
                  //   console.log('---------------------------cron 2');

                  //   console.log('Time -- ' + detail.duration_time);
                  var startTime = detailQuery.createdAt;

                  //  var startTime = new Date();

                  if (detail.duration_type == 'hours') {
                    console.log(detail.duration_time);
                    //     startTime.setHours(startTime.getHours() + detail.duration_time);
                    startTime.setMinutes(startTime.getMinutes() + detail.duration_time*60);

                    console.log('Start-Time =================='+ startTime);
                  } else if (detail.duration_type == 'minute') {
                    startTime.setMinutes(startTime.getMinutes() + detail.duration_time);
                  } else {
                    startTime.setHours(startTime.getHours() + detail.duration_time * 24);
                  }
                  // console.log('---')

                  let endTime = new Date(startTime.getTime() + 1000);
                  // console.log('End Time'+endTime);


                  var now = moment(startTime);
                  var current = moment(new Date());


                  var duration = moment.duration(now.diff(current));
                  var minutes = duration.asMinutes();
                  console.log('Minutes'+minutes)
                  if (minutes>=0 && minutes<=1) {
                    console.log('Start Time'+startTime);

                    j2 = schedule.scheduleJob('job2', startTime, async function (detail, customer) {

                      console.log('Schedule');
                      var funnelUpdate = await funnelTrack.findByIdAndUpdate(detailQuery._id, { status: true },
                        async function (err, result, detail, customer) {

                          if (err) {
                            console.log('err');
                          } else {

                            var funnelTemplate = await funnelDetail.findById(result.funnelStep);
                            var customerDetail = await Customers.findById(result.customer);

                            var subject = funnelTemplate.subject;
                            var m = funnelTemplate.template;
                            var m1 = m.replace("{first_name}", customerDetail.first_name);
                            var message = m1.replace("{last_name}", customerDetail.last_name);


                            await sendEmail(customerDetail.email, subject, message);
                          }
                        });

                    });
                  }
                  //   j2.cancel();

                } else {
                  //  console.log('NE')
                }


              }
            }

          }
        }



      });
    }
  } catch (error) {
    console.log('Error')
  }
}

