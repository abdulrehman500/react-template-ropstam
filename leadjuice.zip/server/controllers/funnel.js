const Funnel = require('../models/funnel');
const Staff = require('../models/staff');
const FunnelStep = require('../models/funnelDetail');
const {check , validationResult} = require('express-validator');
var mongoose = require('mongoose');

exports.getAllFunnels = async (req, res) => {


  try {

    if(res.locals.loggedInUser.role=='staff')
    {
      var staffLoged= await Staff.findOne({user:res.locals.loggedInUser._id});
       // return res.status(200).json({data:staffLoged,meta:{message:"Record Found",status:200,errors:null}});
      if(staffLoged)
        req.body.staff=staffLoged._id;
      else
        return res.json({data:null,meta:{message:"Record Not Found",status:200,errors:null }});

    }

    const staff =Funnel.aggregate();
    if(req.body.staff)
      staff.match({ staff: req.body.staff });

    staff.lookup({
      from: "funneldetails",
      localField: "_id",
      foreignField: "funnel",
      as: "steps",
    });
    staff.lookup({
      from: "lists",
      localField: "list_id",
      foreignField: "_id",
      as: "list",
    });
    staff.lookup({
      from: "staffs",
      localField: "staff",
      foreignField: "_id",
      as: "staff",
    });
    staff.lookup({
      from: "customertypes",
      localField: "customer_type",
      foreignField: "_id",
      as: "customer",
    });
    staff.project( {
        _id:"$_id",
        name:{ $ifNull: [ "$name",null ] },
        steps:{$size:"$steps"},
        status:{ $ifNull: [ "$status",null ] },
        customer:{ $ifNull:[
            {
              $arrayElemAt: [ {
                $map: {
                  input: "$customer",
                  as: "e",
                  in: {name: { $ifNull: [ "$$e.name", null ] },
                    _id: { $ifNull: [ "$$e._id", null ] }
                  }
                }
              }, 0 ]
            }

            , null ] },
        list:{ $ifNull:[
            {
              $arrayElemAt: [ {
                $map: {
                  input: "$list",
                  as: "e",
                  in: {name: { $ifNull: [ "$$e.name", null ] },
                    _id: { $ifNull: [ "$$e._id", null ] }
                  }
                }
              }, 0 ]
            }

            , null ] },
        staff:{ $ifNull:[
            {
              $arrayElemAt: [ {
                $map: {
                  input: "$staff",
                  as: "e",
                  in: {first_name: { $ifNull: [ "$$e.first_name" , null ] },
                    last_name: { $ifNull: [ "$$e.last_name" , null ] },
                    _id: { $ifNull: [ "$$e._id", null ] }
                  }
                }
              }, 0 ]
            }

            , null ] },





      });




     //return res.status(200).json({data:req.body.staff,meta:{message:"Record Found",status:200,errors:null}});

    const result=await staff.exec();

    res.status(200).json({data:result,meta:{message:"Record Found",status:200,errors:null}});
  }catch (err){
    return res.status(200).json({ data:null,meta:{message:'Error',status:201,errors: err }});

  }
}

exports.addFunnel = async (req, res) => {




  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(200).json({ data:null,meta:{message:'Validation Error',status:422,errors: errors.array() }});
  }

  if(res.locals.loggedInUser.role=='staff')
  {
    var staffLoged= await Staff.findOne({user:res.locals.loggedInUser._id});
    //  return res.status(200).json({data:staff,meta:{message:"Record Found",status:200,errors:null}});
    if(staffLoged)
      req.body.staff=staffLoged._id;
    else
      return res.json({data:null,meta:{message:"Record Not Found",status:200,errors:null }});

  }
  const cust= new Funnel (req.body);


  try {
    var saveCust = await cust.save();
    return res.status(200).json({ data:saveCust,meta:{message:'Added Successfully',status:200,errors: null }});
  }catch (err){
    return res.status(200).json({ data:null,meta:{message:'Error',status:201,errors: err }});

  }
}
exports.findFunnel = async (req, res) => {


  try {
    const cust=await Funnel.findById(req.params.id);
    return res.status(200).json({ data:cust,meta:{message:'Record Found',status:200,errors: null }});

  }catch (err){
    return res.status(200).json({ data:null,meta:{message:'Error',status:201,errors: err }});

  }
}
exports.cloneFunnel = async (req, res) => {


 // try {
  var id= mongoose.Types.ObjectId();
  if(res.locals.loggedInUser.role=='staff')
  {
    var staffLoged= await Staff.findOne({user:res.locals.loggedInUser._id});
    //  return res.status(200).json({data:staff,meta:{message:"Record Found",status:200,errors:null}});
    if(staffLoged)
      req.body.staff=staffLoged._id;
    else
      return res.json({data:null,meta:{message:"Record Not Found",status:200,errors:null }});

  }
  const cust=await Funnel.findById(req.params.id).exec(
    function(err, doc) {
      doc._id = id;
      doc.name =  doc.name+'(Copy)';
      doc.isNew = true; //<--------------------IMPORTANT
      doc.save();
    }
  );
  const step=await FunnelStep.find({funnel:mongoose.Types.ObjectId(req.params.id)}).exec(
    function(err, docs) {
      var friends = docs.map(function(record) {
        record._id = mongoose.Types.ObjectId();
        record.funnel = id;
        record.isNew = true; //<--------------------IMPORTANT
        record.save();

      });
     // console.log(docs);

    }
  );

    return res.status(200).json({ data:null,meta:{message:'Cloned Successfully',status:200,errors: null }});
/*  }catch (err){
    return res.status(200).json({ data:null,meta:{message:'Error',status:201,errors: err }});

  }*/
}
exports.deleteFunnel = async (req, res) => {


  try {
    const cust=await Funnel.findByIdAndDelete(req.params.id);

    return res.status(200).json({ data:null,meta:{message:'Deleted Successfully',status:200,errors: null }});
  }catch (err){
    return res.status(200).json({ data:null,meta:{message:'Error',status:201,errors: err }});

  }
}
exports.updateFunnel = async (req, res) => {


  try {
    if(res.locals.loggedInUser.role=='staff')
    {
      var staffLoged= await Staff.findOne({user:res.locals.loggedInUser._id});
      //  return res.status(200).json({data:staff,meta:{message:"Record Found",status:200,errors:null}});
      if(staffLoged)
        req.body.staff=staffLoged._id;
      else
        return res.json({data:null,meta:{message:"Record Not Found",status:200,errors:null }});

    }
    const cust=await Funnel.updateOne({_id:req.params.id},
      {$set:req.body}
    );
    return res.status(200).json({ data:null,meta:{message:'Updated Successfully',status:200,errors: null }});

  }catch (err){
    return res.status(200).json({ data:null,meta:{message:'Error',status:201,errors: err }});

  }
}

exports.addFunnelStep = async (req, res) => {

 /* const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(200).json({ data:null,meta:{message:'Validation Error',status:422,errors: errors.array() }});
  }*/
  req.body.funnel=req.params.fid;
  if(req.body.template_id === null || req.body.template_id == '') {
    delete req.body.template_id;
  }

  const cust= new FunnelStep (req.body);
  try {
    var saveCust = await cust.save();
    return res.status(200).json({ data:saveCust,meta:{message:'Added Successfully',status:200,errors: null }});
 }catch (err){
    return res.status(200).json({ data:null,meta:{message:'Error',status:201,errors: err }});

  }
}

exports.getFunnelSteps = async (req, res) => {


  try {

    const staff=await FunnelStep.find({funnel:req.params.fid}).populate('customer_type', '_id name').populate('template_id', '_id templateHtml');


    res.json({data:staff,meta:{message:"Record Found",status:200,errors:null}});
  }catch (err){
    return res.status(200).json({ data:null,meta:{message:'Error',status:201,errors: err }});

  }
}
exports.findFunnelStep = async (req, res) => {


  try {

    const staff=await FunnelStep.findById(req.params.id).populate('customer_type', '_id name').populate('first_status', '_id name').populate('second_status', '_id name');


    res.json({data:staff,meta:{message:"Record Found",status:200,errors:null}});
  }catch (err){
    return res.status(200).json({ data:null,meta:{message:'Error',status:201,errors: err }});

  }
}
exports.deleteFunnelStep = async (req, res) => {


  try {
    const cust=await FunnelStep.findByIdAndDelete(req.params.id);

    return res.status(200).json({ data:null,meta:{message:'Deleted Successfully',status:200,errors: null }});
  }catch (err){
    return res.status(200).json({ data:null,meta:{message:'Error',status:201,errors: err }});

  }
}

exports.updateFunnelStep = async (req, res) => {


  try {


    if(req.body.customer_type === null || req.body.customer_type == '') {
      delete req.body.customer_type;
    }
    if(req.body.type === null || req.body.type == '') {
      delete req.body.type;
    }
    if(req.body.template_id === null || req.body.template_id == '') {
      delete req.body.template_id;
    }
    const cust=await FunnelStep.updateOne({_id:req.params.id},
      {$set:req.body}
    );
    return res.status(200).json({ data:null,meta:{message:'Updated Successfully',status:200,errors: null }});

  }catch (err){
    return res.status(200).json({ data:null,meta:{message:'Error',status:201,errors: err }});

  }
}
