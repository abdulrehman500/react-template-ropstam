var axios = require('axios');

exports.findScenario = async (req, res) => {

  var config = {
    method: 'get',
    url: 'https://api.integromat.com/v1/organization',
    headers: {
      'Authorization': 'Token 36658a71-8e0e-456b-bc17-67e8d7150103'
    }
  };

  axios(config)
    .then(function (response) {
      console.log(JSON.stringify(response.data));
    })
    .catch(function (error) {

      console.log(error);
      console.log('error');
    });
  return res.json(1);
}
