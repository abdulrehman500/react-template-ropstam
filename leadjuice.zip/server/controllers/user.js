const User = require('../models/user');
const Settings = require('../models/settings');
const bcrypt= require('bcryptjs');
const jwt = require('jsonwebtoken');
const {check , validationResult} = require('express-validator');
var mongoose = require('mongoose');
mongoose.set('useFindAndModify', false);
exports.Register = async (req, res) => {

  const existEmail=await User.findOne({email: req.body.email});
  if(existEmail) {
    res.statusCode = 201;

   return res.send('Email Already Exists');
  }
  const salt= await bcrypt.genSalt(10);
  const hashPwd= await bcrypt.hash(req.body.password,salt);

  const user= new User (
    {
      first_name: req.body.first_name,
      last_name: req.body.last_name,
      email: req.body.email,
      password: hashPwd


    }
  );


  try {
    var saveUser = await user.save();
    res.json(saveUser);
  }catch (err){
    res.json({message:err});

  }
}
exports.Login = async (req, res) => {




  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(200).json({ data:null,meta:{message:'Validation Error',status:422,errors: errors.array() }});
  }

var cemail=req.body.email;

  const user=await User.findOne({email: cemail.toLowerCase()});
  if(!user) {
    //res.statusCode = 201;

    //return res.send('Email Not Found');
    return res.status(200).json({data:null,meta:{message:"Email Not Found",status:201,errors:null}});

  }
  const validPwd=await bcrypt.compare(req.body.password,user.password);
  if(!validPwd) {
    //  res.statusCode = 201;
    return res.status(200).json({data:null,meta:{message:"Invalid Password",status:201,errors:null}});

  }
  const token= jwt.sign({_id:user._id,role:user.role,status:user.status},process.env.TOKEN_SECREAT);

  // res.header({"authToken":token}).send(token);
  return  res.status(200).json({data:{token:token},meta:{message:"Login Successfull",status:200,errors:null}});


}
exports.Settings = async (req, res) => {


  const settings=await Settings.findOne();
  return res.status(200).json({data:settings,meta:{message:"Website Settings",status:201,errors:null}});


}

exports.updateSettings = async (req, res) => {

//console.log(req.body);
  const result=await Settings.findOne();

  var id= mongoose.Types.ObjectId();
  if(result) {
    var query = { _id: result._id };
  }
  else {


    var query = { _id: id };
  }

//  return res.status(200).json({data:null,meta:{message:"Website Settings",status:201,errors:null}});
if(req.body.isEmail)
  var update = {emailSettings:req.body};
else
  var update = {twilioSettings:req.body};
  var options = {
    // Return the document after updates are applied
    new: true,
    // Create a document if one isn't found. Required
    // for `setDefaultsOnInsert`
    upsert: true,
    setDefaultsOnInsert: true
  };
  const user=await Settings.findOneAndUpdate(query,update,options);

  return res.status(200).json({data:user,meta:{message:"Website Settings",status:200,errors:null}});


}

