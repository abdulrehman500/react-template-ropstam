const Staff = require('../models/staff');
const {check , validationResult} = require('express-validator');
var mongoose = require('mongoose');
const jwt = require('jsonwebtoken');
const bcrypt= require('bcryptjs');
const User = require('../models/user');
let multer = require('multer');

exports.getAllStaff = async (req, res) => {




 // try {
    // const staff =await Staff.find();


  let query = Staff.aggregate();
if(req.params.cid)
  query.match({ clinic: mongoose.Types.ObjectId(req.params.cid) });

  query.lookup({
      from: "clinics",
      localField: "clinic",
      foreignField: "_id",
      as: "clinic",
    }
  );
  query.lookup({
      from: "customers",
      localField: "_id",
      foreignField: "staff_id",
      as: "customer",
    }
  );
  query.project({
    _id:"$_id",
    first_name:{ $ifNull: [ "$first_name",null ] },
    last_name:{ $ifNull: [ "$last_name",null ] },
    image:{ $ifNull: [ "$image",null] },
    phone:{ $ifNull: [ "$phone",null] },
    email:{ $ifNull: [ "$email", null ] },
    address:{ $ifNull: [ "$address", null ] },
    status:{ $ifNull: [ "status", null ] },
    admin:{ $ifNull: [ "$admin", false ] },
    clinic:{ $ifNull:[
        {
          $arrayElemAt: [ {
            $map: {
              input: "$clinic",
              as: "e",
              in:
                {name:  { $ifNull: [ "$$e.name", null ] },
                  id:  { $ifNull: [ "$$e._id", null ] }}

            }
          }, 0 ]
        }

        , "Prospect" ] },
    customers:{$size:"$customer"}


  });


const result=await query.exec();
    res.json({data:result,meta:{message:"Record Found",status:200,errors:null}});

  /*}catch (err){
    res.json({message:err})

  }*/
}

exports.addStaff = async (req, res) => {

  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(200).json({ data:null,meta:{message:'Validation Error',status:422,errors: errors.array() }});
  }


    if(req.file)
      req.body.image=req.file.filename;
  try {
    const salt= await bcrypt.genSalt(10);
    const hashPwd= await bcrypt.hash(req.body.password,salt);


    const user= new User ({first_name:req.body.first_name,last_name:req.body.last_name,password:hashPwd,email:req.body.email,role:"staff",status:true});
    var saveUser = await user.save();
    req.body.user=saveUser._id;


    const staff= new Staff (req.body);

    var saveStaff = await staff.save();
    return res.status(200).json({ data:saveStaff,meta:{message:'Added Successfully',status:200,errors: null }});

  }catch (err){
    return res.status(200).json({ data:null,meta:{message:'Error',status:201,errors: err }});

  }


}

exports.findStaff = async (req, res) => {


  try {
    const staff=await Staff.findById(req.params.id).populate('clinic');
    return res.status(200).json({ data:staff,meta:{message:'Record Found',status:200,errors: null }});

  }catch (err){
    return res.status(200).json({ data:null,meta:{message:'Error',status:201,errors: err }});

  }
}
exports.myStaffList = async (req, res) => {
  if(res.locals.loggedInUser.role=='staff')
  {
    var staffLoged= await Staff.findOne({user:res.locals.loggedInUser._id});
     //return res.status(200).json({data:staffLoged,meta:{message:"Record Found",status:200,errors:null}});
    if(staffLoged) {
      req.body.id = staffLoged._id;
      req.body.clinic = staffLoged.clinic;
      req.body.type = staffLoged.admin;
    }
    else
      return res.json({data:null,meta:{message:"Record Not Found",status:200,errors:null }});

  }

  if(req.body.type)
  {
    const staff=await Staff.find({clinic:req.body.clinic}).select('first_name last_name ');
    return res.status(200).json({ data:staff,meta:{message:'Record Found',status:200,errors: null }});

  }
  const staff=await Staff.find({_id:req.body.id}).select('first_name last_name ');
  return res.status(200).json({ data:staff,meta:{message:'Single Record Found',status:200,errors: null }});





}
exports.myProfile = async (req, res) => {


  try {
    if(res.locals.loggedInUser.role=='staff')
    {
      var staffLoged= await Staff.findOne({user:res.locals.loggedInUser._id});
      // return res.status(200).json({data:staff,meta:{message:"Record Found",status:200,errors:null}});
      if(staffLoged)
        req.body.staff=staffLoged._id;
      else
        return res.json({data:null,meta:{message:"Record Not Found",status:200,errors:null }});

    }
    const staff=await Staff.findById(req.body.staff).populate('clinic','name');
    return res.status(200).json({ data:staff,meta:{message:'Record Found',status:200,errors: null }});

  }catch (err){
    return res.status(200).json({ data:null,meta:{message:'Error',status:201,errors: err }});

  }
}
exports.deleteStaff = async (req, res) => {


  try {
    const staff=await Staff.findByIdAndDelete(req.params.id);

    res.status(200).json(staff);
  }catch (err){
    return res.status(200).json({ data:null,meta:{message:'Error',status:201,errors: err }});

  }
}
exports.updateStaff = async (req, res) => {




  try {

    const staf = await Staff.findById(req.params.id);

    const checkMail = await User.findOne({email:req.body.email});


    if(checkMail) {

      if (staf.user.toString() != checkMail._id.toString())
        return res.status(200).json({data: null,meta: {message: 'Email Already Exists',status: 202,errors: null}});
    }

    if (req.file) {
      req.body.image = req.file.filename;

      if (staf.image)
        await unlinkAsync('public/staff_images/' + staf.image)
    }

    if(req.body.clinic === null || req.body.clinic == '') {
      delete req.body.clinic;
    }
          delete req.body.email;

    const staff=await Staff.findOneAndUpdate({_id:req.params.id},
      {$set:req.body}
    );

    var id= mongoose.Types.ObjectId();
    if(staff.user) {
      var query = { _id: staff.user };
    }
    else {


      var query = { _id: id };

      const cli1=await Staff.findByIdAndUpdate(req.params.id, {user:id} );
    }

    const salt= await bcrypt.genSalt(10);
    const hashPwd= await bcrypt.hash(req.body.password,salt);



    var update = {first_name:req.body.first_name,last_name:req.body.last_name,password:hashPwd,email:req.body.email,role:"staff",status:true};

    if(req.body.password === null || req.body.password == '') {
      delete update.password;
    }    var options = {
      // Return the document after updates are applied
      new: true,
      // Create a document if one isn't found. Required
      // for `setDefaultsOnInsert`
      upsert: true,
      setDefaultsOnInsert: true
    };
    const user=await User.findOneAndUpdate(query,update,options);

    return res.status(200).json({ data:null,meta:{message:'Updated Successfully',status:200,errors: null }});
  }catch (err){
    return res.status(200).json({ data:null,meta:{message:'Error',status:201,errors: err }});

  }
}

exports.editMyProfile = async (req, res) => {
console.log(req.body);
console.log(req.file);

  try {


    if(res.locals.loggedInUser.role=='staff')
    {
      var staffLoged= await Staff.findOne({user:res.locals.loggedInUser._id});
      // return res.status(200).json({data:staff,meta:{message:"Record Found",status:200,errors:null}});
      if(staffLoged)
      {
        req.body.staff=staffLoged._id;
         if (req.file) {
             console.log(1);
      req.body.image = req.file.filename;

      if (staffLoged.image)
        await unlinkAsync('public/staff_images/' + staffLoged.image)
    }
      }
      else
        return res.json({data:null,meta:{message:"Record Not Found",status:200,errors:null }});

    }
    
     
    if(req.body.clinic === null || req.body.clinic == '') {
      delete req.body.clinic;
    }
          delete req.body.email;

    const staff=await Staff.updateOne({_id:req.body.staff},
      {$set:req.body}
    );

    return res.status(200).json({ data:null,meta:{message:'Updated',status:200,errors: null }});

  }catch (err){
    return res.status(200).json({ data:null,meta:{message:'Error',status:201,errors: err }});

  }
}
