const sgMail = require('@sendgrid/mail');

const Template = require('../models/emailTemplates');
const funnelDetail = require('../models/funnelDetail');


exports.sendMail = async (req, res) => {
 // const list =await Template.findById('5f3a69ed3fda8d2cc047f510').populate('template_id');
  var funnelTemplate = await funnelDetail.findById('5f27ca7fd4d76c09648fc67e').populate('template_id');

/*
  templateHtml = list.templateHtml.replace(/\\"/g, '"');

  var m1 = templateHtml.replace("{first_name}", 'Ather');
  var html = m1.replace("{last_name}", 'Bin Uqba Zaid');
*/


//console.log(html);
  //return res.status(200).json({ data:funnelTemplate,meta:{message:'Added Successfully',status:200,errors: null }});





  try {
    sgMail.setApiKey("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");

    const msg = {
      to: 'ather.uqba@ropstam.com',
      from: 'do-no-reply@ropstam.com',
      subject: 'Sending with Twilio SendGrid is Fun',
      text: "Message",
    };

  //  return res.status(200).json({ data:null,meta:{message:'Added Successfully',status:200,errors: null }});
    try {
       var response =await sgMail.send(msg);
       return res.status(200).json({ data:null,meta:{message:"Added",status:200,errors: null }});

    }catch (err){
      return res.status(200).json({ data:null,meta:{message:err.message,status:err.code,errors: null }});

    }
  }catch (err){
   // return res.status(200).json({ data:null,meta:{message:' Successfully',status:201,errors: null }});

    res.json({message:err})

  }
}

