var twilio = require('twilio');
const Customer = require('../models/customer');
const Conversations = require('../models/conversations');
var mongoose = require('mongoose');


var socket = require('socket.io-client')('http://192.168.1.123:3000');


exports.newSMS = async (req, res) => {
  console.log('new Sms')
  console.log(req.body)

}
exports.getConservationList = async (req, res) => {


console.log(1);
  const conv =await Conversations.find().populate('customer_id' ,'first_name last_name image phone');
  return res.status(200).json({ data:conv,meta:{message:'Conversation List',status:200,errors: null }});


}
exports.newSMSGet = async (req, res) => {
  console.log('new Sms Get')
  console.log(req.body)

}

exports.makeCall = async (req, res) => {
  var accountSid = process.env.TWILIO_SID; // Your Account SID from www.twilio.com/console
  var authToken = process.env.TWILIO_AUTH;   // Your Auth Token from www.twilio.com/console

  var twilio = require('twilio');
  var client = new twilio(accountSid, authToken);

  console.log('new Sms Get')
  console.log(req.body)
  client.calls
    .create({
      url: 'http://demo.twilio.com/docs/voice.xml',
      to: '+16474002581',
      from: '+13433126182'
    })
    .then(call => console.log(call.sid));
  return res.status(200).json({ data:null,meta:{message:'Called',status:200,errors: null }});

}
exports.newSMSWebhook = async (req, res) => {
  console.log('new Sms Get')
  console.log(req.body)

}
  exports.listSMS = async (req, res) => {

  var accountSid = process.env.TWILIO_SID; // Your Account SID from www.twilio.com/console
  var authToken = process.env.TWILIO_AUTH;   // Your Auth Token from www.twilio.com/console

  var twilio = require('twilio');
  var client = new twilio(accountSid, authToken);
  let   data=[];

  await client.messages.list({limit: 20})
    .then(messages => messages.forEach(

      m => {
      var  record=m;
data.push(record);

      }

    ));
  return res.status(200).json({ data:data,meta:{message:'Record Found Successfully',status:200,errors: null }});


}

exports.testAPI = async (req, res) => {


  // '+16474002581'
 // try {
    var accountSid = process.env.TWILIO_SID; // Your Account SID from www.twilio.com/console
    var authToken = process.env.TWILIO_AUTH;   // Your Auth Token from www.twilio.com/console

    var twilio = require('twilio');

      var client = await new twilio(accountSid, authToken);
  var response =await client.messages
    .create({
      body: req.body.message,
      from: '+13433126182',
      statusCallback: 'http://juice.ropstambpo.com:3000/api/newSMS',

      to:  req.body.phone
    })
    .then(message =>
    {
      console.log(message);
      return res.status(200).json({data:null,meta:{message:'SMS Sent',status:200,errors:null}});

    }).done();
    /*.catch(e => {
      return res.status(200).json({data:null,meta:{message:e.message,status:e.code,errors:null}});

    })*/


   // return res.status(200).json({data:null,meta:{message:"SMS Sent",status:200,errors:null}});

/*  }catch (err){
  return res.status(200).json({ data:null,meta:{message:'Error',status:201,errors: null }});

}*/
}


exports.call = async (req, res) => {

  var accountSid = process.env.TWILIO_SID; // Your Account SID from www.twilio.com/console
  var authToken = process.env.TWILIO_AUTH;   // Your Auth Token from www.twilio.com/console

  var twilio = require('twilio');
  var client = new twilio(accountSid, authToken);

  // '+16474002581'


  await client.calls
    .create({
      url: 'http://demo.twilio.com/docs/voice.xml',
      to: req.body.phone,
      from:'+13433126182'
    })
    .then(call => console.log(call));
  console.log('Lead Juice');
  return res.status(200).json({data:null,meta:{message:"SMS Sent",status:200,errors:null}});
}




exports.conservation = async (req, res) => {

  var accountSid = process.env.TWILIO_SID; // Your Account SID from www.twilio.com/console
  var authToken = process.env.TWILIO_AUTH;   // Your Auth Token from www.twilio.com/console

  var twilio = require('twilio');
  var client = new twilio(accountSid, authToken);

  // '+16474002581'


  const conv =await Conversations.find();

  return res.status(200).json({data:conv,meta:{message:"Conversation List",status:200,errors:null}});

  await client.conversations.conversations
    .create({
      friendlyName: 'My Secound Conversation',attributes:[
        topic=> "feedback"
      ]
    })
    .then(conversation => console.log(conversation.sid));
  return res.status(200).json({data:null,meta:{message:"SMS Sent",status:200,errors:null}});
}
exports.allConversations = async (req, res) => {

  var accountSid = process.env.TWILIO_SID; // Your Account SID from www.twilio.com/console
  var authToken = process.env.TWILIO_AUTH;   // Your Auth Token from www.twilio.com/console

  var twilio = require('twilio');
  var client = new twilio(accountSid, authToken);
 //const conv1=await client.conversations.conversations.list();
  //return res.status(200).json({data:conv1,meta:{message:"Messages List",status:200,errors:null}})
  // '+16474002581'

  const conv =await Conversations.find({display:true}).populate('customer_id' ,'first_name last_name image phone');

  return res.status(200).json({data:conv,meta:{message:"Conversation List",status:200,errors:null}});

  /*conv=await client.conversations.conversations
    .list();
  return res.status(200).json({data:conv,meta:{message:"Messages List",status:200,errors:null}});
*/
}

exports.deleteConversation = async (req, res) => {

  var accountSid = process.env.TWILIO_SID; // Your Account SID from www.twilio.com/console
  var authToken = process.env.TWILIO_AUTH;   // Your Auth Token from www.twilio.com/console

  var twilio = require('twilio');
  var client = new twilio(accountSid, authToken);

  // '+16474002581'

  try {
    var conversations = await client.conversations.conversations(req.params.sid)
      .remove();

    var del = await Conversations.find({ conversation_id: req.params.sid })
      .remove();


    return res.status(200)
      .json({
        data: null,
        meta: {
          message: "Conservation Removed",
          status: 200,
          errors: null
        }
      });
  } catch (e) {
    return res.status(200).json({data: null,
        meta: {
          message: "Error ",
          status: 201,
          errors: e
        }  });

  }
}

exports.addConservation = async (req, res) => {

  var accountSid = process.env.TWILIO_SID; // Your Account SID from www.twilio.com/console
  var authToken = process.env.TWILIO_AUTH;   // Your Auth Token from www.twilio.com/console

  var twilio = require('twilio');
  var client = new twilio(accountSid, authToken);



  client.conversations.conversations('CHa96b6f3063a14806b4a60f14001d0af5')
    .participants
    .list({limit: 20})
    .then(participants => participants.forEach(p => console.log(p.sid)));
  return res.status(200).json({data:null,meta:{message:"SMS Sent",status:200,errors:null}});


  // '+16474002581'

  const cust=await Customer.findById('5f44aa2781594ddba8857420');

  var cid=null;
  await client.conversations.conversations
    .create({
      friendlyName: cust.first_name

    })
    .then(conversation =>{
      cid=conversation.sid
    }

    );

  await client.conversations.conversations(cid)
    .participants
    .create({
      'messagingBinding.address': cust.phone,
      'messagingBinding.proxyAddress': '+13433126182'
    })
    .then(participant => {
      req.body.customer_id=cust._id;
      req.body.staff_id=cust.staff_id;
      req.body.conversation_id=cid;
      console.log(req.body);

      var conv=new Conversations(req.body);
      conv.save();

    })
    .catch(message =>
  {
    console.log(message.code)
    var conversations=client.conversations.conversations(cid)
      .remove();
  });


  return res.status(200).json({data:null,meta:{message:"SMS Sent",status:200,errors:null}});
}
exports.searchConversations = async (req, res) => {


console.log(req.params.query);
  var userName = req.params.query; //userName = 'Juan David Nicholls';
  var searchString = new RegExp(userName, 'i');


  const searchId=[];
  const cust =await Customer.find({})
    .and([
      { $or: [{first_name: searchString},{last_name: searchString}] },
    ]).select('_id')
    .exec();

cust.forEach(element => {
 searchId.push(element._id);
})
  const conv =await Conversations.find({}).where('customer_id').in(searchId).populate('customer_id' ,'first_name last_name image phone');


  return res.status(200).json({data:conv,meta:{message:"Conversation List Search",status:200,errors:null}});

}

exports.findConversations = async (req, res) => {

  var accountSid = process.env.TWILIO_SID; // Your Account SID from www.twilio.com/console
  var authToken = process.env.TWILIO_AUTH;   // Your Auth Token from www.twilio.com/console

  var twilio = require('twilio');
  var client = new twilio(accountSid, authToken);

  // '+16474002581'


 var detail= await client.conversations.conversations(req.params.sid)
    .messages
    .list({page:1});


  return res.status(200).json({data: detail,meta: {message: "SMS List",status: 200,errors: null} });

}
exports.sendSMS = async (req, res) => {

  var accountSid = process.env.TWILIO_SID; // Your Account SID from www.twilio.com/console
  var authToken = process.env.TWILIO_AUTH;   // Your Auth Token from www.twilio.com/console

  var twilio = require('twilio');
  var client = new twilio(accountSid, authToken);
//console.log(req.body);
 // return res.status(200).json({data: null,meta: {message: "SMS Sent",status: 200,errors: null} });

  // '+16474002581'
 // try {
/*    await client.conversations.webhooks()
      .update({
        filters:['onMessageAdded','onMessageUpdated'],
        preWebhookUrl: 'http://juice.ropstambpo.com:3000/api/newSMS',
        postWebhookUrl: 'http://juice.ropstambpo.com:3000/api/newSMSWebhook',
        method: 'POST'
      })
      .then(webhook => console.log(webhook));*/

 /* client.conversations.webhooks()
    .fetch()
    .then(webhook => console.log(webhook));
  return res.status(200).json({data: null,meta: {message: "SMS Sent",status: 200,errors: null} });*/
/*
  await  client.conversations.webhooks()
    .update({
      filters: ['onMessageAdd','onMessageAdded', 'onMessageUpdate', 'onMessageRemove'],
      target: 'webhook',
      preWebhookUrl: 'http://juice.ropstambpo.com:3000/api/newSMS',
      postWebhookUrl: 'http://juice.ropstambpo.com:3000/api/newSMS',
      method: 'POST'
    })
    .then(webhook => console.log(webhook))
*/

  client.conversations.webhooks()
    .update({
      filters: ['onMessageAdded','onConversationUpdated'],
      postWebhookUrl: 'http://leadjuice.ropstambpo.com:3000/api/newSMSWebhooks',
      url: 'http://leadjuice.ropstambpo.com:3000/api/newSMSWebhooks',
      //   preWebhookUrl: 'https://company.com/filtering-and-permissions',
      method: 'POST'
    });



  await client.conversations.conversations(req.params.sid)
      .messages
      .create({
        author: 'User',
        body: req.body.message
      }).then(message => console.log(message));

const query = { "conversation_id": req.params.sid };
// Set some fields in that document
const update = {
  "$set": {
    "display": "true"
  }
};
  const conv =await Conversations.findOneAndUpdate(query, update);

  socket.emit('chat-message','Hello World HaSSAN')
req.app.io.emit('chat-message','Hello World hASSAN 2');

  return res.status(200).json({data: null,meta: {message: "SMS Sent",status: 200,errors: null} });
/*  }
  catch (e) {
    return res.status(200).json({data: null,meta: {message: "Error ",status: 201,errors: e} });

  }*/
}
