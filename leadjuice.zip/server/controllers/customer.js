const Customers = require('../models/customer');
const Staff = require('../models/staff');
const CustomerTypes = require('../models/customerTypes');
const List = require('../models/list');
const {check , validationResult} = require('express-validator');
var mongoose = require('mongoose');
var twilio = require('twilio');
const Conversations = require('../models/conversations');

const fs = require('fs')
const { promisify } = require('util')

const unlinkAsync = promisify(fs.unlink)

exports.getCustomerTypes = async (req, res) => {


  try {


    const types =await CustomerTypes.find().select('name');
    res.json({data:types,meta:{message:"Record Found",status:200,errors:null }});
  }catch (err){
    return res.status(200).json({ data:null,meta:{message:'Error',status:201,errors: err }});


  }
}
exports.addCustomerTypes = async (req, res) => {


    const cust= CustomerTypes.insertMany([
      {name:'Prospect'},{name:'Lead'},{name:'Consult'},{name:'Closed'}]
    );


}

exports.getAllCustomers = async (req, res) => {


  try {
if(res.locals.loggedInUser.role=='staff')
{
  var staff= await Staff.findOne({user:res.locals.loggedInUser._id});
 // return res.status(200).json({data:staff,meta:{message:"Record Found",status:200,errors:null}});
if(staff)
  req.params.sid=staff._id;
else
 return res.json({data:null,meta:{message:"Record Not Found",status:200,errors:null }});

}
    let query = Customers.aggregate();

    if(req.params.sid) {
      // console.log(req.params);
      query.match({ staff_id: mongoose.Types.ObjectId(req.params.sid) });
    }
    if(req.params.type) {
      // console.log(req.params);
      let cType =await CustomerTypes.findOne({name:req.params.type});

      query.match({ type: mongoose.Types.ObjectId(cType._id) });
    }
    if(req.params.id) {
      // console.log(req.params);
      query.match({ list_id: mongoose.Types.ObjectId(req.params.id) });
    }
    query.lookup({
        from: "staffs",
        localField: "staff_id",
        foreignField: "_id",
        as: "staff",
      }
    );
    query.lookup({
        from: "lists",
        localField: "list_id",
        foreignField: "_id",
        as: "list_name",
      }
    );
    query.lookup({
        from: "customertypes",
        localField: "type",
        foreignField: "_id",
        as: "clientType",
      }
    );
    query.project(
      {
        _id:"$_id",
        first_name:{ $ifNull: [ "$first_name",null ] },
        last_name:{ $ifNull: [ "$last_name",null ] },
        phone:{ $ifNull: [ "$phone",null] },
                    image:{ $ifNull: [ "$image", null ] },

        email:{ $ifNull: [ "$email", null ] },
        address:{ $ifNull: [ "$address", null ] },
        gender:{ $ifNull: [ "$gender", "Male" ] },
        city:{ $ifNull: [ "$city", null ] },
    //    label:{ $ifNull: [ "$label", null ] },
        list_name:{ $ifNull:[
            {
              $arrayElemAt: [ {
                $map: {
                  input: "$list_name",
                  as: "l",
                  in: { $ifNull: [ "$$l.name", null ] }
                }
              }, 0 ]
            }

            , null ] },
        type:{ $ifNull:[
            {
              $arrayElemAt: [ {
                $map: {
                  input: "$clientType",
                  as: "e",
                  in: {name:{ $ifNull: [ "$$e.name", null ] },
                    _id:{ $ifNull: [ "$$e._id", null ] }}
                }
              }, 0 ]
            }

            , "Prospect" ] },


        time:{ $ifNull: [ "$time", "Today" ] },
        staff:{
          $arrayElemAt: [ {
            $map: {
              input: "$staff",
              as: "e",
              in:
                {name: { $concat: [ { $ifNull: [ "$$e.first_name", '' ] }, " ",{ $ifNull: [ "$$e.last_name", '' ] }  ] }}
            }
          }, 0 ]
        },



      }

    );

    const result=await query.exec();

    res.json({data:result,meta:{message:"Record Found",status:200,errors:null }});
  }catch (err){
    return res.status(200).json({ data:null,meta:{message:'Error',status:201,errors: err }});

  }
}
exports.getStaffCustomers = async (req, res) => {


  try {
    const staff =await Customers.aggregate(
      [ {
        $lookup: {
          from: "staffs",
          localField: "staff_id",
          foreignField: "_id",
          as: "staff",
        },

      },
        {
          $lookup: {
            from: "customertypes",
            localField: "type",
            foreignField: "_id",
            as: "clientType",
          },

        },

        {
          $project:{
            _id:"$_id",
            first_name:{ $ifNull: [ "$first_name",null ] },
            last_name:{ $ifNull: [ "$last_name",null ] },
            phone:{ $ifNull: [ "$phone",null] },
            email:{ $ifNull: [ "$email", null ] },
            address:{ $ifNull: [ "$address", null ] },
            gender:{ $ifNull: [ "$gender", "Male" ] },
            city:{ $ifNull: [ "$city", null ] },
            type:{ $ifNull:[
                {
                  $arrayElemAt: [ {
                    $map: {
                      input: "$clientType",
                      as: "e",
                      in: { $ifNull: [ "$$e.name", null ] }
                    }
                  }, 0 ]
                }

                , "Prospect" ] },


            time:{ $ifNull: [ "$time", "Today" ] },
            // staff:{ $ifNull: [ "$staff", null ] },
            staff:{
              $arrayElemAt: [ {
                $map: {
                  input: "$staff",
                  as: "e",
                  in: /*{ $cond: {
                      if: {$eq: ["$$e", null]},
                      then: {name: "Unknown"},
                      else: {name: { $concat: [ { $ifNull: [ "$$e.first_name", '' ] }, " ",{ $ifNull: [ "$$e.last_name", '' ] }  ] } }
                    }
                  }*/
                    {name: { $concat: [ { $ifNull: [ "$$e.first_name", '' ] }, " ",{ $ifNull: [ "$$e.last_name", '' ] }  ] }}
                }
              }, 0 ]
            },


          }
        },


      ]);
    res.json({data:staff,meta:{message:"Record Found",status:200,errors:null }});
  }catch (err){
    return res.status(200).json({ data:null,meta:{message:'Error',status:201,errors: err }});

  }
}

exports.addCustomer = async (req, res) => {
  var accountSid = process.env.TWILIO_SID; // Your Account SID from www.twilio.com/console
  var authToken = process.env.TWILIO_AUTH;   // Your Auth Token from www.twilio.com/console

  var twilio = require('twilio');
  var client = new twilio(accountSid, authToken);

  const errors = validationResult(req);
  if (!errors.isEmpty()) {
       if(req.file)
    await unlinkAsync(req.file.path)
    return res.status(200).json({ data:null,meta:{message:'Validation Error',status:422,errors: errors.array() }});
  }
  
  if (req.file)
    req.body.image = req.file.filename;
  const cust= new Customers (req.body);
  if(req.body.staff_id === null || req.body.staff_id == '') {
    delete req.body.staff_id;
  }
  if(req.body.list_id === null || req.body.list_id == '') {
    delete req.body.list_id;
  }
  if(req.body.type === null || req.body.type == '') {
    delete req.body.type;
  }

  try {
    var saveCust = await cust.save();
    //if(saveCust)
    {
      console.log(123);
      var cid=null;
      await client.conversations.conversations
        .create({
          friendlyName: cust.first_name

        })
        .then(conversation =>{
            cid=conversation.sid
          }

        );
   /* await  client.conversations.conversations(cid).webhooks
        .create({
          'configuration.filters': ['onMessageAdded', 'onMessageUpdated'],
          'configuration.url': 'http://juice.ropstambpo.com:3000/api/newSMSWebhooks',
          target: 'webhook'
        });*/

      client.conversations.webhooks()
        .update({
          filters: ['onMessageAdded'],
          postWebhookUrl: 'http://leadjuice.ropstambpo.com:3000/api/newSMSWebhooks',
          //   preWebhookUrl: 'https://company.com/filtering-and-permissions',
          method: 'POST'
        });
      await client.conversations.conversations(cid)
        .participants
        .create({
          'messagingBinding.address': cust.phone,
          'messagingBinding.proxyAddress': '+13433126182'
        })
        .then(participant => {
          req.body.customer_id=cust._id;
          req.body.staff_id=cust.staff_id;
          req.body.conversation_id=cid;

          var conv=new Conversations(req.body);
          conv.save();

        })
        .catch(message =>
        {

          cust.phone = '';
          cust.save();
          var conversations=client.conversations.conversations(cid)
            .remove();
          //return res.status(200).json({ data:null,meta:{message:'Invalid Phone',status:201,errors: null }});

        });
    }
    return res.status(200).json({ data:saveCust,meta:{message:'Added Successfully',status:200,errors: null }});
  }catch (err){
    return res.status(200).json({ data:null,meta:{message:'Error',status:201,errors: err }});

  }
}
exports.addList = async (req, res) => {

  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(200).json({ data:null,meta:{message:'Validation Error',status:422,errors: errors.array() }});
  }

  if(res.locals.loggedInUser.role=='staff')
  {
    var staff= await Staff.findOne({user:res.locals.loggedInUser._id});
    //  return res.status(200).json({data:staff,meta:{message:"Record Found",status:200,errors:null}});
    if(staff)
      req.body.clinic=staff.clinic;
    else
      return res.json({data:null,meta:{message:"Record Not Found",status:200,errors:null }});

  }
  const cust= new List (req.body);


  try {
    var saveCust = await cust.save();
    return res.status(200).json({ data:saveCust,meta:{message:'Added Successfully',status:200,errors: null }});
  }catch (err){
    return res.status(200).json({ data:null,meta:{message:'Error',status:201,errors: err }});

  }
}
exports.getList = async (req, res) => {


  try {
    if(res.locals.loggedInUser.role=='staff')
    {
      var staff= await Staff.findOne({user:res.locals.loggedInUser._id});
     //  return res.status(200).json({data:staff,meta:{message:"Record Found",status:200,errors:null}});
      if(staff)
        req.body.clinic=staff.clinic;
      else
        return res.json({data:null,meta:{message:"Record Not Found",status:200,errors:null }});

    }

    const types =await List.find({clinic:req.body.clinic}).select('name').populate('clinic','name');

    let query = List.aggregate();
    if(req.body.clinic) {
      // console.log(req.params);
      query.match({ clinic: mongoose.Types.ObjectId(req.body.clinic) });
    }
    query.lookup({
        from: "clinics",
        localField: "clinic",
        foreignField: "_id",
        as: "clinic",
      }
    );
    query.lookup({
        from: "customers",
        localField: "_id",
        foreignField: "list_id",
        as: "customer",
      }
    );
    query.project({
      _id:"$_id",
      name:{ $ifNull: [ "$name",null ] },

      clinic:{ $ifNull:[
          {
            $arrayElemAt: [ {
              $map: {
                input: "$clinic",
                as: "e",
                in:
                  {name:  { $ifNull: [ "$$e.name", null ] },
                    id:  { $ifNull: [ "$$e._id", null ] }}

              }
            }, 0 ]
          }

          , null ] },
      customers:{$size:"$customer"}


    });
    const result=await query.exec();

    res.json({data:result,meta:{message:"Record Found",status:200,errors:null }});
  }catch (err){
    return res.status(200).json({ data:null,meta:{message:'Error',status:201,errors: err }});


  }
}

exports.findList = async (req, res) => {


  try {
    const types =await List.find({ clinic :mongoose.Types.ObjectId(req.params.id) }).select('name');
    res.json({data:types,meta:{message:"Record Found",status:200,errors:null }});
  }catch (err){
    return res.status(200).json({ data:null,meta:{message:'Error',status:201,errors: err }});


  }
}
exports.listDetail = async (req, res) => {


  try {
    const types =await List.findById(req.params.id);
    res.json({data:types,meta:{message:"Record Found",status:200,errors:null }});
  }catch (err){
    return res.status(200).json({ data:null,meta:{message:'Error',status:201,errors: err }});


  }
}

exports.findCustomer = async (req, res) => {


  try {
   // const cust=await Customers.findById(req.params.id);

    const cust =await Customers.aggregate(
      [
        { "$match" : { _id :mongoose.Types.ObjectId(req.params.id) } },
        {
          $lookup: {
            from: "staffs",
            localField: "staff_id",
            foreignField: "_id",
            as: "staff",
          },

        },
        {
          $lookup: {
            from: "customertypes",
            localField: "type",
            foreignField: "_id",
            as: "clientType",
          },

        },
        {
          $lookup: {
            from: "lists",
            localField: "list_id",
            foreignField: "_id",
            as: "clientList",
          },

        },

        {
          $project:{
            _id:"$_id",
            first_name:{ $ifNull: [ "$first_name",null ] },
            last_name:{ $ifNull: [ "$last_name",null ] },
            phone:{ $ifNull: [ "$phone",null] },
            email:{ $ifNull: [ "$email", null ] },
            address:{ $ifNull: [ "$address", null ] },
            gender:{ $ifNull: [ "$gender", "Male" ] },
            dob:{ $ifNull: [ "$dob", null ] },
            address2:{ $ifNull: [ "$address2", null ] },
            created_at:{ $ifNull: [ "$created_at", null ] },
            city:{ $ifNull: [ "$city", null ] },
            state:{ $ifNull: [ "$state", null ] },
            country:{ $ifNull: [ "$country", null ] },
            zip:{ $ifNull: [ "$zip", null ] },

            insurance_id:{ $ifNull: [ "$insurance_id", null ] },
            insurance_provider:{ $ifNull: [ "$insurance_provider", null ] },
            insurance_group:{ $ifNull: [ "$insurance_group", null ] },
            insurance_phone:{ $ifNull: [ "$insurance_phone", null ] },
            price:{ $ifNull: [ "$price", null ] },
            image:{ $ifNull: [ "$image", null ] },
            notes:{ $ifNull: [ "$notes", null ] },

            type:{ $ifNull:[
                {
                  $arrayElemAt: [ {
                    $map: {
                      input: "$clientType",
                      as: "e",
                      in: {name: { $ifNull: [ "$$e.name", null ] },
                        _id: { $ifNull: [ "$$e._id", null ] }
                      }
                    }
                  }, 0 ]
                }

                , "Prospect" ] },
            list:{ $ifNull:[
                {
                  $arrayElemAt: [ {
                    $map: {
                      input: "$clientList",
                      as: "e",
                      in: {name: { $ifNull: [ "$$e.name", null ] },
                        _id: { $ifNull: [ "$$e._id", null ] }
                      }
                    }
                  }, 0 ]
                }

                , null ] },


            time:{ $ifNull: [ "$time", "Today" ] },
            // staff:{ $ifNull: [ "$staff", null ] },
            staff:{
              $arrayElemAt: [ {
                $map: {
                  input: "$staff",
                  as: "e",
                  in: /*{ $cond: {
                      if: {$eq: ["$$e", null]},
                      then: {name: "Unknown"},
                      else: {name: { $concat: [ { $ifNull: [ "$$e.first_name", '' ] }, " ",{ $ifNull: [ "$$e.last_name", '' ] }  ] } }
                    }
                  }*/
                    {name: { $concat: [ { $ifNull: [ "$$e.first_name", '' ] }, " ",{ $ifNull: [ "$$e.last_name", '' ] }  ] },
                      _id: { $ifNull: [ "$$e._id", null ] }
                    }
                }
              }, 0 ]
            },


          }
        },





      ]).limit(1);
    return res.status(200).json({ data:cust[0],meta:{message:'Record Found',status:200,errors: null }});

  }catch (err){
    res.json({message:err})

  }
}
exports.deleteCustomer = async (req, res) => {


  try {
    const cust=await Customers.findByIdAndDelete(req.params.id);
    const conv=await Conversations.find({customer_id:mongoose.Types.ObjectId(req.params.id)}).remove();

    return res.status(200).json({ data:null,meta:{message:'Deleted Successfully',status:200,errors: null }});
  }catch (err){
    return res.status(200).json({ data:null,meta:{message:'Error',status:201,errors: err }});

  }
}
exports.deleteList = async (req, res) => {


  try {
    const cust=await List.findByIdAndDelete(req.params.id);

    return res.status(200).json({ data:null,meta:{message:'Deleted Successfully',status:200,errors: null }});
  }catch (err){
    return res.status(200).json({ data:null,meta:{message:'Error',status:201,errors: err }});

  }
}
exports.updateList = async (req, res) => {


  try {
    if(res.locals.loggedInUser.role=='staff')
    {
      var staff= await Staff.findOne({user:res.locals.loggedInUser._id});
      // return res.status(200).json({data:staff,meta:{message:"Record Found",status:200,errors:null}});
      if(staff)
        req.body.clinic=staff.clinic;
      else
        return res.json({data:null,meta:{message:"Record Not Found",status:200,errors:null }});

    }
    const cust=await List.updateOne({_id:req.params.id},
      {$set:req.body}
    );
    return res.status(200).json({ data:null,meta:{message:'Updated Successfully',status:200,errors: null }});
  }catch (err){
    return res.status(200).json({ data:null,meta:{message:'Error',status:201,errors: err }});

  }
}



exports.updateCustomer = async (req, res) => {


  try {
    const oldPhone=req.body.phone;
  var accountSid = process.env.TWILIO_SID; // Your Account SID from www.twilio.com/console
  var authToken = process.env.TWILIO_AUTH;   // Your Auth Token from www.twilio.com/console

  var twilio = require('twilio');
  var client = new twilio(accountSid, authToken);

    /*if(res.locals.loggedInUser.role=='staff')
    {
      var staff= await Staff.findOne({user:res.locals.loggedInUser._id});
      //  return res.status(200).json({data:staff,meta:{message:"Record Found",status:200,errors:null}});
      if(staff)
        req.body.staff_id=staff._id;
      else
        return res.json({data:null,meta:{message:"Record Not Found",status:200,errors:null }});

    }*/
//console.log(req.body);
    if(req.body.staff_id === null || req.body.staff_id == '') {
      delete req.body.staff_id;
    }
    if(req.body.type === null || req.body.type == '') {
      delete req.body.type;
    }
    if(req.body.list_id === null || req.body.list_id == '') {
      delete req.body.list_id;
    }
    const custF=await Customers.findById(req.params.id);


if (req.file) {
      console.log(123);
      req.body.image = req.file.filename;

    if (custF.image)
        await unlinkAsync('public/contact_images/' + custF.image)
    }
    
    
    const cust=await Customers.updateOne({_id:req.params.id},
      {$set:req.body}
    );
    if(cust)
    {
      var cid=null;
      const findConv= await Conversations.findOne({customer_id:mongoose.Types.ObjectId(req.params.id)});

if(!findConv) {
console.log('new');
  await client.conversations.conversations
    .create({
      friendlyName: cust.first_name

    })
    .then(conversation =>{
        cid=conversation.sid
      }

    );
/*  await client.conversations.conversations(cid).webhooks
    .create({
      'configuration.filters': ['onMessageAdded'],
      'configuration.url': 'http://juice.ropstambpo.com:3000/api/newSMSWebhooks',
      target: 'webhook'
    });*/

  client.conversations.webhooks()
    .update({
      filters: ['onMessageAdded'],
      postWebhookUrl: 'http://leadjuice.ropstambpo.com:3000/api/newSMSWebhooks',
   //   preWebhookUrl: 'https://company.com/filtering-and-permissions',
      method: 'POST'
    });
  console.log('webhook');
  await client.conversations.conversations(cid)
    .participants
    .create({
      'messagingBinding.address': req.body.phone,
      'messagingBinding.proxyAddress': '+13433126182'
    })
    .then(participant => {
      req.body.customer_id=req.params.id;
      req.body.staff_id=req.body.staff_id;
      req.body.conversation_id=cid;

      var conv=new Conversations(req.body);
      conv.save();

    })
    .catch(message =>
    {


      const custPhone=Customers.updateOne({_id:req.params.id},
        {$set:{phone:''}}
      );
      var conversations=client.conversations.conversations(cid)
        .remove();
      return res.status(200).json({ data:null,meta:{message:'Invalid Phone or Already Exists 1',status:201,errors: null }});

    });
}
else {
  //const custF=await Customers.findById(req.params.id);
if(custF.phone == oldPhone) {

}else{
  await client.conversations.conversations(findConv.conversation_id)
    .participants
    .list({ limit: 20 })
    .then(participants => participants.forEach(p => p.remove()));

/*  await client.conversations.conversations(findConv.conversation_id).webhooks
    .create({
      'configuration.filters': ['onMessageAdded'],
      'configuration.url': 'http://juice.ropstambpo.com:3000/api/newSMSWebhooks',
      target: 'webhook'
    });*/

  client.conversations.webhooks()
    .update({
      filters: ['onMessageAdded'],
      postWebhookUrl: 'http://leadjuice.ropstambpo.com:3000/api/newSMSWebhooks',
      //   preWebhookUrl: 'https://company.com/filtering-and-permissions',
      method: 'POST'
    });
  console.log('webhook Update');

  await client.conversations.conversations(findConv.conversation_id)
    .participants
    .create({
      'messagingBinding.address': req.body.phone,
      'messagingBinding.proxyAddress': '+13433126182'
    })
    .then(participant => {


    })
    .catch(message => {

      console.log(message);
      const custPhone = Customers.updateOne({ _id: req.params.id },
        { $set: { phone: '' } }
      );
      var conversations = client.conversations.conversations(cid)
        .remove();
      return res.status(200)
        .json({
          data: null,
          meta: {
            message: 'Invalid Phone or Already Exists 1',
            status: 201,
            errors: null
          }
        });

    });
}
}

    }



    return res.status(200).json({ data:null,meta:{message:'Updated Successfully',status:200,errors: null }});

  }catch (err){
    return res.status(200).json({ data:null,meta:{message:'Error',status:201,errors: err }});

  }
}

exports.updateCustomerType = async (req, res) => {


  try {
    if(res.locals.loggedInUser.role=='staff')
    {
      var staff= await Staff.findOne({user:res.locals.loggedInUser._id});
      //  return res.status(200).json({data:staff,meta:{message:"Record Found",status:200,errors:null}});
      if(staff)
        req.body.staff_id=staff._id;
      else
        return res.json({data:null,meta:{message:"Record Not Found",status:200,errors:null }});

    }
if(req.body.type) {
  const cust = await Customers.updateOne({ _id: req.params.id },
    { $set: { type: req.body.type } }
  );
}
    return res.status(200).json({ data:null,meta:{message:'Changed Successfully',status:200,errors: null }});

  }catch (err){
    return res.status(200).json({ data:null,meta:{message:'Error',status:201,errors: err }});

  }
}
