var mongoose = require('mongoose');
const FunnelDetail = require('./funnelDetail');

const Clinic = require('./clinic');
const Staff = require('./staff')
const List = require('./list')

var Schema =  mongoose.Schema;

var funnelSchema =new mongoose.Schema({

  clinic: { type: Schema.Types.ObjectId, ref: 'Clinic', required: true },

  price: {
    type: Number
  },
  date: {
    type: Date,
    default:Date.now
  },
  status: {
    type: Boolean,
    default:true
  },

}, {timestamps: true});


module.exports = mongoose.model('ClinicSpent',funnelSchema);
