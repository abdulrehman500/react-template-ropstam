var mongoose = require('mongoose');
const FunnelDetail = require('./funnelDetail');

const Clinic = require('./clinic');
const Staff = require('./staff')
const List = require('./list')

var Schema =  mongoose.Schema;

var funnelSchema =new mongoose.Schema({

  clinic: { type: Schema.Types.ObjectId, ref: 'Clinic', required: false },
  staff: { type: Schema.Types.ObjectId, ref: 'Staff',default:null },
  list: { type: Schema.Types.ObjectId, ref: 'List', required: false },
  label: {
    type: String
  },
  webhook: {
    type: String
  },
  url: {
    type: String
  },
  status: {
    type: Boolean,
    default:true
  },

}, {timestamps: true});


module.exports = mongoose.model('ClinicFunnels',funnelSchema);
