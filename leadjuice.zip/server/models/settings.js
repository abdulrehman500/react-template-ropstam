var mongoose = require('mongoose');


var Schema =  mongoose.Schema;
var EmailSchema = new Schema({ api_key: String, from: String, auth_token: String, email: String,test_email: String,status: Boolean });
var TwilioSchema = new Schema({ api_key: String, from: String,test_number: String, auth_token: String, call_forward: String,status: Boolean });


var settingSchema =new mongoose.Schema({
  facebook: String,
  twitter: String,
  google: String,
  youtube: String,
  instagram: String,
  linkedin: String,
  social: String,
  logo: String,
  emailSettings: EmailSchema,
  twilioSettings: TwilioSchema,
});


module.exports = mongoose.model('Settings',settingSchema);
