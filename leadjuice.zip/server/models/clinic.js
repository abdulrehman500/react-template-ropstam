var mongoose = require('mongoose');
const Staff = require('./staff')
const User = require('./user');

var Schema =  mongoose.Schema;

var ZapierSchema = new Schema({ path: String });

var EmailSchema = new Schema({ api_key: String, from: String, auth_token: String, email: String,test_email: String,status: Boolean });
var TwilioSchema = new Schema({ api_key: String, from: String,test_number: String, auth_token: String, call_forward: String,status: Boolean });

var clinicSchema =new mongoose.Schema({
  user: { type: Schema.Types.ObjectId, ref: 'User', required: false },

  clinic_id: {
    type: String
  },
  name: {
    type: String
  },
  phone: {
    type: String
  },
  email: {
    type: String
  },
  address: {
    type: String
  },

  city: String,
  state: String,
  country: String,
  zip: String,

  facebook: String,
  twitter: String,
  google: String,
  youtube: String,
  instagram: String,
  linkedin: String,
  social: String,
  description: String,

  logo: String,


  zapier: [ZapierSchema],
  emailSettings: [EmailSchema],
  twilioSettings: [TwilioSchema],
  status: Boolean,

});


module.exports = mongoose.model('Clinic',clinicSchema);
