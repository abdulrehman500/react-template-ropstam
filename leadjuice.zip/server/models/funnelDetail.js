var mongoose = require('mongoose');
const Funnel = require('./funnel');
const CustomerTypes = require('./customerTypes');
const List = require('./list');
const EmailTemplate = require('./emailTemplates');

var Schema =  mongoose.Schema;


var funnelSchema =new mongoose.Schema({

  funnel: { type: Schema.Types.ObjectId, ref: 'Funnel' },
  list_id: { type: Schema.Types.ObjectId, ref: 'List',default:null },
  template_id: { type: Schema.Types.ObjectId, ref: 'EmailTemplate',default:null },

  name: {
    type: String
  },
  type: {
    type: String,
    default: 'email',
    enum: ["email", "sms"]
  },
  subject: {
    type: String
  },

  duration_action: {
    type: String,
    default: 'after',
    enum: ["exact", "after","date"]
  },
  exact_date: {
    type: Date
  },
  exact_time: {
    type: String
  },
  duration_type: {
    type: String,
    default: null,
    //enum: ["days", "hours","minute"]
  },
  duration_time: {
    type: Number
  },
  step: {
    type: Number
  },
  template: {
    type: String
  },
  status: {
    type: Boolean,
    default: true
  },


  customer_type: { type: Schema.Types.ObjectId, ref: 'CustomerTypes' },

  first_status: { type: Schema.Types.ObjectId, ref: 'CustomerTypes' },
  second_status: { type: Schema.Types.ObjectId, ref: 'CustomerTypes' },

});


module.exports = mongoose.model('FunnelDetail',funnelSchema);
