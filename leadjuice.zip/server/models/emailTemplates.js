var mongoose = require('mongoose');
const FunnelDetail = require('./funnelDetail');
const Customer = require('./customer');

var Schema =  mongoose.Schema;

var funnelSchema =new mongoose.Schema({


  name: {
    type: String
  },
  template: {
    type: Object
  }
  ,
  templateHtml: {
    type: String
  }

}, {timestamps: true});


module.exports = mongoose.model('EmailTemplate',funnelSchema);
