var mongoose = require('mongoose');
const FunnelDetail = require('./funnelDetail');
const Customer = require('./customer');

var Schema =  mongoose.Schema;

var funnelSchema =new mongoose.Schema({

  funnelStep: { type: Schema.Types.ObjectId, ref: 'funnelStep' },
  customer: { type: Schema.Types.ObjectId, ref: 'Customer' },
  status: {
    type: Boolean,
    default:false
  },

}, {timestamps: true});


module.exports = mongoose.model('FunnelTrack',funnelSchema);
