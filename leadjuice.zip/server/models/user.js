var mongoose = require('mongoose');
var Schema =  mongoose.Schema;

var userSchema =new mongoose.Schema({

  first_name: {
    type: String
  },
  last_name: {
    type: String
  },
  email: {
    type: String,
    unique: true
  },
  password: {
    type: String
  },
  role: {
    type: String,
    default: 'staff',
    enum: ["admin", "staff", "company", "customer"]
  },
  status: {
    type: Boolean,
    default:true
  },



});


module.exports = mongoose.model('User',userSchema);
