var mongoose = require('mongoose');
const Clinic = require('./clinic')

var Schema =  mongoose.Schema;

var listSchema =new mongoose.Schema({

  name: {
    type: String
  },
  clinic: { type: Schema.Types.ObjectId, ref: 'Clinic' }




});


module.exports = mongoose.model('List',listSchema);
