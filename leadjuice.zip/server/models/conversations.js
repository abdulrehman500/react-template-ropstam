var mongoose = require('mongoose');
const Customer = require('./customer');
const Staff = require('./staff');
const Clinic = require('./clinic');
const EmailTemplate = require('./emailTemplates');

var Schema =  mongoose.Schema;


var conv =new mongoose.Schema({

  customer_id: { type: Schema.Types.ObjectId, ref: 'Customer' },
  staff_id: { type: Schema.Types.ObjectId, ref: 'Staff',default:null },
  clinic_id: { type: Schema.Types.ObjectId, ref: 'Clinic',default:null },

  conversation_id: {
    type: String
  },
  status: {
    type: Boolean,
    default:true
  },
  un_read: {
    type: String
  },
  last_message: {
    type: String
  },
  display: {
    type: Boolean,
    default:false
  },





}, {timestamps: true});


module.exports = mongoose.model('Conversations',conv);
