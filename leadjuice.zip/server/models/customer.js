var mongoose = require('mongoose');
var Schema =  mongoose.Schema;
const Staff = require('./staff')
const List = require('./list')
const Types = require('./customerTypes')

var customerSchema =new mongoose.Schema({

  staff_id: { type: Schema.Types.ObjectId, ref: 'Staff',default:null },
  type: { type: Schema.Types.ObjectId, ref: 'Types',default:null },
  list_id: { type: Schema.Types.ObjectId, ref: 'List',default:null },


  first_name: {
    type: String
  },
  last_name: {
    type: String
  },
  gender: {
    type: String,
    default: 'Male',
    enum: ["Male", "Female"]
  },
  phone: {
    type: String
  },

  email: {
    type: String
  },
  dob: {
    type: Date
  },
  address: {
    type: String
  },
  address2: {
    type: String
  },
  created_at: String,
  city: String,
  state: String,
  country: String,
  zip: String,

  insurance_id: String,
  insurance_provider: String,
  insurance_group: String,
  insurance_phone: String,

  image: String,
  price: Number,
  notes: String,




}, {timestamps: true});


module.exports = mongoose.model('Customer',customerSchema);
