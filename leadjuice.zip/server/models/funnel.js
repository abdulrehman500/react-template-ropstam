var mongoose = require('mongoose');
const Staff = require('./staff');

const CustomerTypes = require('./customerTypes');
const List = require('./list');

var Schema =  mongoose.Schema;

var funnelSchema =new mongoose.Schema({

  name: {
    type: String
  },
  status: {
    type: Boolean,
    default:true
  },

  staff: { type: Schema.Types.ObjectId, ref: 'Staff' },
  list_id: { type: Schema.Types.ObjectId, ref: 'List' },
  customer_type: { type: Schema.Types.ObjectId, ref: 'CustomerTypes' },

});


module.exports = mongoose.model('Funnel',funnelSchema);
