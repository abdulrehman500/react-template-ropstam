var mongoose = require('mongoose');
const Clinic = require('./clinic');
const User = require('./user');

var Schema =  mongoose.Schema;

var staffSchema =new mongoose.Schema({

  clinic: { type: Schema.Types.ObjectId, ref: 'Clinic', required: false },
  user: { type: Schema.Types.ObjectId, ref: 'User', required: false },

  first_name: {
    type: String
  },
  last_name: {
    type: String
  },
  gender: {
    type: String,
    default: 'Male',
    enum: ["Male", "Female"]
  },
  phone: {
    type: String
  },
  email: {
    type: String
  },
  password: {
    type: String
  },
  active: {
    type: Boolean,
    default:true
  },
  admin: {
    type: Boolean,
    default:false
  },

  address: {
    type: String
  },
  occupation: {
    type: String
  },



  facebook: String,
  twitter: String,
  google: String,
  youtube: String,
  instagram: String,
  linkedin: String,
  social: String,
  image: String,

});


module.exports = mongoose.model('Staff',staffSchema);
