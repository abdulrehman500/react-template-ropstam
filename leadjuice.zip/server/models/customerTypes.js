var mongoose = require('mongoose');
const Clinic = require('./clinic')

var Schema =  mongoose.Schema;

var customerSchema =new mongoose.Schema({

  name: {
    type: String
  },


});


module.exports = mongoose.model('CustomerTypes',customerSchema);
