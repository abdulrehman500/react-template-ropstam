const express = require('express');
const router = express.Router();
const clinicController=require('../controllers/clinic')
const staffController=require('../controllers/staff')
const customerController=require('../controllers/customer')
const userController=require('../controllers/user')
const funnelController=require('../controllers/funnel')
const dashboardController=require('../controllers/dashboard')
const sendgridController=require('../controllers/sendgrid')
const twilioController=require('../controllers/twilio')
const notficationController=require('../controllers/notification')
const schedularController=require('../controllers/schedular')
const clickFunnel=require('../controllers/clickFunnel')
const emailTemplate=require('../controllers/emailTemplate')
const intergromat=require('../controllers/intergromat')
const verify=require('../middlewares/verifyUser')
const checkLogin = require('../validations/login')
const checkFunnel = require('../validations/funnel')
const checkClinic = require('../validations/clinic')
const checkStaff = require('../validations/staff')
const checkCustomer = require('../validations/customers')
var socket = require('socket.io-client')('http://leadjuice.ropstambpo.com:3000');
let multer = require('multer');



var storageClinic = multer.diskStorage({


  destination: function (req, file, cb) {
    cb(null, 'public/clinic_images')
  },
  filename: function (req, file, cb) {
    cb(null, Date.now() + '-' +file.originalname )
  }
})
var storageStaff = multer.diskStorage({


  destination: function (req, file, cb) {
    cb(null, 'public/staff_images')
  },
  filename: function (req, file, cb) {
    cb(null, Date.now() + '-' +file.originalname )
  }
})
var storageContact = multer.diskStorage({


  destination: function (req, file, cb) {
    cb(null, 'public/contact_images')
  },
  filename: function (req, file, cb) {
    cb(null, Date.now() + '-' +file.originalname )
  }
})
var uploadClinic = multer({ storage: storageClinic } );
var uploadStaff = multer({ storage: storageStaff } );
var uploadContact = multer({ storage: storageContact } );


var upload = multer();
var upload = multer({ dest: 'uploads/' })





socket.on('connect', function () {

  console.log("client connected.");





});




router.post('/newSMSWebhooks', twilioController.newSMSWebhook);


router.post('/login',/*[checkLogin.userValidationRules()],*/ userController.Login);
router.post('/register',[checkLogin.userValidationRules(),verify], userController.Register);



router.get('/listCustomers',verify, schedularController.customers);

router.get('/clickFunnel,verify', clickFunnel.findFunnel);

router.get('/scenario',verify, intergromat.findScenario);

router.post('/addTemplate',verify, emailTemplate.addTemplate);
router.get('/getTemplates',verify, emailTemplate.allTemplate);
router.get('/getTemplate/:id',verify, emailTemplate.getTemplate);
router.patch('/updateTemplate/:id',verify, emailTemplate.updateTemplate);


router.post('/newSMS', twilioController.newSMS);
router.get('/newSMS', twilioController.newSMSGet);



router.get('/makeCall', twilioController.makeCall);
router.get('/testSmsAPI', twilioController.testAPI);
router.get('/conservation',verify, twilioController.conservation);
router.get('/conservation/:sid',verify, twilioController.findConversations);
router.get('/deleteConversation/:sid', twilioController.deleteConversation);
router.get('/allConversations', twilioController.allConversations);
router.post('/sendSMS/:sid', twilioController.sendSMS);
router.get('/addConservation',verify, twilioController.addConservation);


router.get('/searchConversations/:query',verify, twilioController.searchConversations);

router.get('/getConservationList',verify, twilioController.getConservationList);




router.get('/call',verify, twilioController.call);
router.get('/listSMS', twilioController.listSMS);
router.get('/sendMail',verify, sendgridController.sendMail);
router.get('/notifications',verify, notficationController.getAll);

router.get('/sendNotification',verify, notficationController.sendNotification);

router.post('/myClinic',verify, clinicController.myClinic);
router.post('/editMyClinicSMS',verify, clinicController.editMyClinicSMS);
router.post('/editMyClinicEmail',verify, clinicController.editMyClinicEmail);
router.post('/editMyClinic',verify, clinicController.editMyClinic);
router.post('/editMyProfile',uploadStaff.single('file'),verify, staffController.editMyProfile);
router.post('/myProfile',verify, staffController.myProfile);



router.get('/dashboard',verify, dashboardController.getDasboardData);
router.get('/dashboardPayment',verify, dashboardController.getPaymentData);
router.get('/hotLeads',verify, dashboardController.getHotLeads);
router.get('/settings',verify, dashboardController.getSettings);

router.get('/getClinic',[verify], clinicController.getAllClinic);
router.post('/addClinic',uploadClinic.single('file'),[checkClinic.userValidationRules()], clinicController.addClinic);
router.get('/getClinic/:id',verify, clinicController.findClinic);
router.get('/getClinicStaff/:cid',verify, staffController.getAllStaff);
router.delete('/deleteClinic/:id',verify, clinicController.deleteClinic);
router.patch('/updateClinic/:id',uploadClinic.single('file'),verify, clinicController.updateClinic);
router.post('/editClinicEmail/:id',verify, clinicController.updateEmail);
router.post('/editClinicSMS/:id',verify, clinicController.updateSMS);
router.post('/addClinicFunnel/:id',verify, clinicController.addClinicFunnel);
router.get('/getClinicFunnel/:id',verify, clinicController.getClinicFunnel);





router.post('/addFunnel',[checkFunnel.funnelValidationRules(),verify], funnelController.addFunnel);
router.get('/getFunnels',verify, funnelController.getAllFunnels);
router.delete('/deleteFunnel/:id',verify, funnelController.deleteFunnel);
router.get('/getFunnel/:id',verify, funnelController.findFunnel);
router.patch('/updateFunnel/:id',verify, funnelController.updateFunnel);

router.post('/addFunnelStep/:fid',[checkFunnel.funnelValidationRules(),verify], funnelController.addFunnelStep);
router.get('/getFunnelSteps/:fid',verify, funnelController.getFunnelSteps);
router.delete('/deleteFunnelStep/:id',verify, funnelController.deleteFunnelStep);
router.get('/getFunnelStep/:id',verify, funnelController.findFunnelStep);
router.patch('/updateFunnelStep/:id',verify, funnelController.updateFunnelStep);
router.patch('/cloneFunnel/:id',verify, funnelController.cloneFunnel);


router.get('/getStaff',verify, staffController.getAllStaff);
router.post('/addStaff',uploadStaff.single('file'),[checkStaff.userValidationRules()], staffController.addStaff);
router.get('/getStaff/:id',verify, staffController.findStaff);
router.delete('/deleteStaff/:id',verify, staffController.deleteStaff);
router.patch('/updateStaff/:id',uploadStaff.single('file'),verify, staffController.updateStaff);
router.get('/getStaffCustomers/:sid',verify, customerController.getAllCustomers);


router.get('/getCustomerTypes',verify, customerController.getCustomerTypes);
router.get('/addCustomerTypes',verify, customerController.addCustomerTypes);
router.patch('/updateCustomerType/:id',verify, customerController.updateCustomerType);

router.post('/addList',verify,customerController.addList);
router.get('/getList',verify,customerController.getList);
router.get('/getList/:id',verify,customerController.findList);
router.get('/listDetail/:id',verify,customerController.listDetail);
router.patch('/updateList/:id',verify,customerController.updateList);
router.delete('/deleteList/:id',verify,customerController.deleteList);


router.get('/getCustomers',[verify], customerController.getAllCustomers);
router.get('/getCustomers/:type',[verify], customerController.getAllCustomers);
router.get('/getListCustomers/:id',verify, customerController.getAllCustomers);
router.post('/addCustomer', uploadContact.single('file'),[checkCustomer.userValidationRules(),verify], customerController.addCustomer);
router.get('/getCustomer/:id',verify, customerController.findCustomer);
router.delete('/deleteCustomer/:id',verify, customerController.deleteCustomer);
router.patch('/updateCustomer/:id',uploadContact.single('file'),verify, customerController.updateCustomer);


router.get('/adminSettings',[verify], userController.Settings);
router.post('/updateSettings',[verify], userController.updateSettings);

router.get('/myStaffList',[verify], staffController.myStaffList);


router.get('/*', function(req, res) {
  return res.status(404).send({data:null,meta:{msg:'Invalid Route ',status:404,error:null}});
});




module.exports = router
