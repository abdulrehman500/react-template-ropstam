

const User = require('../models/user');


const { body, validationResult } = require('express-validator')
const userValidationRules = () => {
  return [
    body('staff_id').notEmpty().withMessage('Please Select Staff ID'),
    body('list_id').notEmpty().withMessage('Please Select List'),
    body('type').notEmpty().withMessage('Please Select Contact Type'),
    body('phone').notEmpty().withMessage('Please Enter Phone').isLength({min: 10,max: 15}).withMessage('Phone must be between 10 - 15 characters'),
    body('first_name').notEmpty().isLength({min: 1,max: 50}).withMessage('First Name must have more than 1 characters'),
    body('last_name').notEmpty().isLength({min: 1,max: 50}).withMessage('Last Name must have more than 1 characters'),
    body('email').notEmpty().withMessage('Please Enter Email Address').isEmail().withMessage('Invalid Email Format').custom(value => {
      return User.findOne({email: value}).then(user => {
        if (user) {
          return Promise.reject('E-mail already in use');
        }
      });
    }),
  ]
}

module.exports = {
  userValidationRules,

}
