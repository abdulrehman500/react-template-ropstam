

const User = require('../models/user');
const Clinic = require('../models/clinic');


const { body, check, validationResult,expressValidator } = require('express-validator')
const userValidationRules = function (req,res,next) {

  return [
    // username must be an email
    check('phone').notEmpty().withMessage('Please Enter Phone').isLength({min: 10,max: 15}).withMessage('Phone must be between 10 - 15 characters'),
    check('name').notEmpty().isLength({min: 2,max: 50}).withMessage('Name must have more than 2 characters'),
    body('email').notEmpty().withMessage('Please Enter Email Address').isEmail().withMessage('Invalid Email Format').custom(value => {
      return User.findOne({email: value}).then(user => {
        if (user) {
          return Promise.reject('E-mail already in use');
        }
      });
    }),
    // password must be at least 5 chars long
  ]
}

module.exports = {
  userValidationRules,

}
