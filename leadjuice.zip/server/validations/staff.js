

const User = require('../models/user');
const Clinic = require('../models/clinic');

const { body, validationResult } = require('express-validator')
const userValidationRules = () => {
  return [
    body('clinic').notEmpty().withMessage('Please Select Clinic ID'),
    body('phone').notEmpty().withMessage('Please Enter Phone').isLength({min: 10,max: 15}).withMessage('Phone must be between 10 - 15 characters'),
    body('first_name').notEmpty().isLength({min: 2,max: 50}).withMessage('First Name must have more than 2 characters'),
    body('email').notEmpty().withMessage('Please Enter Email Address').isEmail().withMessage('Invalid Email Format').custom(value => {
      return User.findOne({email: value}).then(user => {
        if (user) {
          return Promise.reject('E-mail already in use');
        }
      });
    }),    body('password').isLength({ min: 5 }),
  ]
}

module.exports = {
  userValidationRules,

}
