



const { body, validationResult } = require('express-validator')
const funnelValidationRules = () => {
  return [
    body('name').notEmpty().isLength({min: 2,max: 50}).withMessage('First Name must have more than 2 characters'),

  ]
}
const funnelStepValidationRules = () => {
  return [
    body('name').notEmpty().isLength({min: 2,max: 50}).withMessage('First Name must have more than 2 characters'),
    body('funnel').notEmpty().withMessage('Please Select Funnel'),
    body('type').notEmpty().withMessage('Please Select Type'),

  ]
}

module.exports = {
  funnelValidationRules,

}
