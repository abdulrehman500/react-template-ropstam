



const { body, validationResult } = require('express-validator')
const userValidationRules = () => {
  return [
    // username must be an email
 //   body('username').isEmail().withMessage('Email Required').isLength({ min: 5 }).withMessage('must be at least 5 chars long'),
    body('email').isEmail(),
    // password must be at least 5 chars long
    body('password').isLength({ min: 5 }),
  ]
}

module.exports = {
  userValidationRules,

}
